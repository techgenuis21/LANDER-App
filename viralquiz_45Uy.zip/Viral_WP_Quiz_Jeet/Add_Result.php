<?php
  $enter_score="";
  $select_quiz_result="";
  $Scores_Statement="";
  $Select_result_image="";
  $questionimgurl="";
  
add_action('admin_init', 'Add_Result_design' );
function Add_Result_design(){
     register_setting( 'Add_Result_option', 'enter_score' );
     register_setting( 'Add_Result_option', 'select_quiz_result' );
     register_setting( 'Add_Result_option', 'Scores_Statement' );
     register_setting( 'Add_Result_option', 'Select_result_image' );
}
function Add_Result_Callback(){
    if ( isset( $_POST['submit'] ) && isset( $_POST['result_hidden_images'] ) ) :
		update_option( 'images_selector', absint( $_POST['result_hidden_images'] ) );
    endif;
  wp_enqueue_media(); 
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="<?=  plugins_url('css/AddNewQuestion.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
<script src='<?php echo plugins_url('js/jquery.js',__FILE__); ?>'></script>
 <script>
 jQuery(document).ready(function(){
     $("body").css("background-color","#F1F1F1");
     $("#submit").click(function(event){
                 var enter_score = $("#enter_score").val();
                 enter_score = encodeURIComponent(enter_score);
                 //var select_quiz_result = $("#select_quiz_result").val();
                // select_quiz_result = encodeURIComponent(select_quiz_result);
                 var Scores_Statement = $("#Scores_Statement").val();
                 Scores_Statement = encodeURIComponent(Scores_Statement);
                 var result_img_path = $("#result_image_show").attr("src");
                 result_img_path = encodeURIComponent(result_img_path);
                 $.ajax({
   		 type: 'GET',
   		 url: '<?php echo plugins_url( 'ajax_pages/ajax_result.php' , __FILE__ );?>',
   		 data: "result_img_path1="+result_img_path+"&enter_score1="+enter_score+"&Scores_Statement1="+Scores_Statement,
                 success: function(msg){alert(msg);
                    $("#result_msg").append('<div id="result_msg" class="result_msg Quiz_msg">'+msg+'</div>');
                  window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Result");
                }
               });   
              event.preventDefault();   
              });
         });
 </script>
<?php
     echo '<div class="wrap">
<span id="addquestion" class="addquestion" style="display: -webkit-box;  display: -moz-inline-box;" ><h1> Manage Result <button id="addresultfeedback" class="page-title-action">Add Result Feedback</button></h1></span>';
     require_once 'All_Result_FeedBack.php';
echo '<form class="addresult_form" method="post" action="options.php">'; ?>
    <?php settings_fields( 'Add_Result_option' ); ?>
    <?php do_settings_sections( 'Add_Result_option' ); ?>
<?php

  $enter_score=esc_attr( get_option('enter_score') );
  $select_quiz_result=esc_attr( get_option('select_quiz_result') );
  $Scores_Statement=esc_attr( get_option('Scores_Statement') );
  $Select_result_image=esc_attr( get_option('Select_result_image') );
?>
<?php
$ct3=0;
for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
     $table_name = $wpdb->prefix."Question"; 
  $quiz_question11 = $wpdb->prepare( "select * from $table_name where quiz_name = %s","$GLOBALS[$k]");
  $questions11=$wpdb->get_results($quiz_question11);//echo '<pre>';print_r($questions11);echo '</pre>';
  $json = json_encode($questions11);
  $jsondecode = json_decode($json, true);
   $ct3= $ct3 + count($jsondecode);
  }//echo $ct3;
  ?>
 <div id="result_msg" class="result_msg Quiz_msg"></div>
 <table class="form-table">
<tr class="sel_pp">
    <th scope="row" style="padding-left: 0px !important;">Select Score :- </th>
    <td>
        <select name="enter_score" id="enter_score" class="enter_score">
<?php
for($i=1;$i<=$ct3;$i++){
?>
            <option value="<?= "$i "; ?>of<?= " $ct3"; ?>"><?= "$i "; ?>of<?= " $ct3"; ?></option>        
<?php
}
?>
</select> (Select the score and remarks based on performance.)</td>
</tr>

 
<tr class="sel_pp">
<th scope="row" style="padding-left: 0px !important;">Type in Feedback :- </th>
<td><textarea style="resize: none;" name="Scores_Statement" id="Scores_Statement" class="Scores_Statement" cols="70" row="1" value=""/></textarea></td>
</tr> 
</table>     
<div class='result_image_show resuimgsho'>
			<img id='result_image_show' src='<?php echo wp_get_attachment_url( get_option( 'images_selector' ) ); ?>' alt="">
		</div>
		<input id="upload_result_image" type="button" class="button resultbtnsub " value="<?php _e( 'Upload image' ); ?>" />
		<input type='hidden' name='result_hidden_images' id='result_hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>
                <input type="submit" id="submit" name="submit" value="Save Changes" class="submitbtnres button button-primary button-large">   


<?php
  echo '</form></div>';
?>
<script>
    function editresult(n,result_quiz_name,score,score_statement,event){
        $(".edit_result").css("display","block");
        $(".wrap").css("display","none");
       // $(".edit_result").find("#hidden_result_quiz_name").html(result_quiz_name);
        $(".edit_result").find("#hidden_result_score").html(score);
        $(".edit_result").find("#hidden_result_score_statement").html(score_statement);
        //result_quiz_name = encodeURIComponent(result_quiz_name);
        score = encodeURIComponent(score);
        score_statement = encodeURIComponent(score_statement);
        
        $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/ajax_result_edit.php' , __FILE__ );?>',
   		data: "score1="+score+"&score_statement1="+score_statement,
                success: function(msg){
                    var obj = $.parseJSON( msg );
                    for(var i=0;i<obj.length;i++){
                       $(".edit_result .form-table .erescore td").find("#enter_score").val(obj[i]['score']); 
                      // $(".edit_result .form-table .eresquiz td .ediselectquiz").find("option[value='"+obj[i]['result_quiz_name']+"']").attr("selected", true); 
                       $(".edit_result .form-table .erescoresta td").find("#Scores_Statement").val(obj[i]['score_statement']); 
                       $(".edit_result .editresultimg").find("img").attr("src", obj[i]['score_image_name']);
                        }  
                   
                    }
               }); 
               event.preventDefault();
    }
    $(document).ready(function(){
     $(".updateresult").click(function(event){
    //var hidden_result_quiz_name = $(".edit_result").find("#hidden_result_quiz_name").text();
   // hidden_result_quiz_name = encodeURIComponent(hidden_result_quiz_name);
    var hidden_result_score = $(".edit_result").find("#hidden_result_score").text();
    hidden_result_score = encodeURIComponent(hidden_result_score);
    var hidden_result_score_statement = $(".edit_result").find("#hidden_result_score_statement").text();
    hidden_result_score_statement = encodeURIComponent(hidden_result_score_statement);
    var enter_score = $(".edit_result .form-table .erescore td").find("#enter_score").val();
    enter_score = encodeURIComponent(enter_score);
   // var quiz_name = $(".edit_result .form-table .eresquiz td").find(".ediselectquiz").val();
   // quiz_name = encodeURIComponent(quiz_name);
    var Scores_Statement = $(".edit_result .form-table .erescoresta td").find("#Scores_Statement").val();
    Scores_Statement = encodeURIComponent(Scores_Statement);
    var img_url = $(".edit_result .editresultimg").find("img").attr("src");
    img_url = encodeURIComponent(img_url);
    
    $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/update_result.php' , __FILE__ );?>',
   		data: "hidden_result_score1="+hidden_result_score+"&hidden_result_score_statement1="+hidden_result_score_statement+"&enter_score1="+enter_score+"&Scores_Statement1="+Scores_Statement+"&img_url1="+img_url,
                success: function(msg){
                    alert(msg);
                     window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Result");
                    }
               });
               event.preventDefault();
     });
    });
</script>
<div class="edit_result" id="edit_result" style="display: none;">
    <span id="hidden_result_quiz_name" class="hidden_result_quiz_name" style="display:none;"></span><span id="hidden_result_score" class="hidden_result_score" style="display:none;"></span><span id="hidden_result_score_statement" class="hidden_result_score_statement" style="display:none;"></span>
  <span id="addquestion" class="addquestion" style="display: -webkit-box;  display: -moz-inline-box;" ><h1 style="font-size: 23px;font-weight: 400;margin: 0;padding: 9px 15px 4px 0;line-height: 29px;"> Edit Result </h1></span>
  <div id="result_msg" class="result_msg Quiz_msg"></div>
 <table class="form-table">
<tr class="sel_pp erescore">
    <th scope="row" style="padding-left: 0px !important;">Enter Score :- </th>
    <td>
     <select name="enter_score" id="enter_score" class="enter_score">
<?php
for($i=1;$i<=$ct3;$i++){
?>
            <option value="<?= "$i "; ?>of<?= " $ct3"; ?>"><?= "$i "; ?>of<?= " $ct3"; ?></option>        
<?php
}
?>
</select> (Select the score and remarks based on performance.)
    </td>
</tr>

 
<tr class="sel_pp erescoresta">
<th scope="row" style="padding-left: 0px !important;">Type in Feedback :- </th>
<td><textarea style="resize: none;" name="Scores_Statement" id="Scores_Statement" class="Scores_Statement" cols="70" row="1" value=""/></textarea></td>
</tr> 
</table>     
  <div class='edit_result_image_show resuimgsho editresultimg'>
			<img alt="" style="width: 200px !important;" id='edit_result_image_show' src='<?php echo wp_get_attachment_url( get_option( 'images_selector' ) ); ?>'>
		</div>
		<input id="edit_result_image" type="button" class="button resultbtnsub" value="<?php _e( 'Upload image' ); ?>" />
		<input type='hidden' name='result_hidden_images' id='result_hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>
                <input type="submit" id="submit" name="submit" value="Save Changes" class="submitbtnres updateresult button button-primary button-large">  
                <a href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_Result" id="resultdelete" class="submitbtnres button button-primary button-large" name="resultdelete"> Back </a>

</div>
 <script>
         jQuery(document).ready(function(){
             $("#wpfooter").css("position","fixed");
             $("#addresultfeedback").click(function(){
                 $(".addresult_form").css("display","block")
                 $("#addresultfeedback").css("display","none");
                 $(".result_table").css("display","none");
             });
           });
 </script>
 <?php
 }
 add_action( 'admin_footer', 'result_media_selector' );

function result_media_selector() {

	$my_saved_attachment_post_id = get_option( 'images_selector', 0 );

	?><script type='text/javascript'>
//--------------------------------------------------------
		jQuery( document ).ready( function( $ ) {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			jQuery('#edit_result_image').on('click', function( event ){

				event.preventDefault();

				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
				
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	
				});

				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#edit_result_image_show' ).attr( 'src', attachment.url ).css( 'width', '200px' );
					$( '#result_hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});
//--------------------------------------------------------
		jQuery( document ).ready( function( $ ) {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			jQuery('#upload_result_image').on('click', function( event ){

				event.preventDefault();

				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
				
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	
				});

				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#result_image_show' ).attr( 'src', attachment.url ).css( 'width', '200px' );
					$( '#result_hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});
	</script><?php
}
?>