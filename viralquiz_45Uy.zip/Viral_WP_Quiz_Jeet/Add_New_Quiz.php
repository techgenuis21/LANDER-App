<?php 
add_action('admin_init', 'Add_New_Quiz' );
function Add_New_Quiz(){ 
    $GLOBALS['quesno']=esc_attr( get_option('quesno') );
    register_setting( 'Add_New_Quiz_option', 'Enter_Quiz_Title' );
    register_setting( 'Add_New_Quiz_option', 'quesno' );
    for($j=1;$j<=$GLOBALS['quesno'];$j++){
    register_setting( 'Add_New_Quiz_option', "activa$j" );
    }
    for($i=1;$i<=$GLOBALS['quesno'];$i++){
    register_setting( 'Add_New_Quiz_option', "activa$i");
    //register_setting( 'Add_New_Quiz_option', 'activate2' );
    }
}
function Add_New_Quiz_Callback(){
   
	if ( isset( $_POST['submit'] ) && isset( $_POST['hidden_images'] ) ) :
		update_option( 'images_selector', absint( $_POST['hidden_images'] ) );
	endif;

	wp_enqueue_media();        
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="<?=  plugins_url('css/AddNewQuestion.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
<script src='<?php echo plugins_url('js/jquery.js',__FILE__); ?>'></script>
<style>
.Enter_Quiz_Title option{width: 200px;}    
</style>
 <script>
 $(document).ready(function(){
     $("body").css("background-color","#F1F1F1");
     $("#submit").click(function(event){
          
                 
                 var quiz_img_path = $("#image_show").attr("src");
                 quiz_img_path = encodeURIComponent(quiz_img_path);
                 var Enter_Quiz_Title = $("#Enter_Quiz_Title").val();
                 Enter_Quiz_Title = encodeURIComponent(Enter_Quiz_Title);
                
                 $.ajax({
   		type: 'GET',
   		url: "<?php echo plugins_url( 'ajax_pages/ajax_quiz.php' , __FILE__ );?>",
   		data: "quiz_img_path1="+quiz_img_path+"&Enter_Quiz_Title1="+Enter_Quiz_Title,
                success: function(msg){
                    $("#Quiz_msg").append('<div id="Quiz_msg" class="Quiz_msg">'+msg+'</div>');
                   window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_New_Quiz");
                }
               });  
              event.preventDefault();
              });
         });
 </script>
<?php
     echo '<div class="wrap">
<span id="addquestion" class="addquestion" style="display: -webkit-box; display: -moz-inline-box;" ><h1> Manage Quiz </h1></span>';
//require_once 'All_Quiz.php';

echo '<form class="addnewquiz_form" method="post"  action="options.php">'; ?>
    <?php settings_fields( 'Add_New_Quiz_option' ); ?>
    <?php do_settings_sections( 'Add_New_Quiz_option' ); ?>
<?php 
@$GLOBALS=[];
@$GLOBALS['hook_suffix']="";
$GLOBALS['Enter_Quiz_Title']=esc_attr( get_option('Enter_Quiz_Title') );

$GLOBALS['quesno']=esc_attr( get_option('quesno') );
for($j=1;$j<=$GLOBALS['quesno'];$j++){
  
array_push($GLOBALS, esc_attr( get_option("activa$j")));
//echo $GLOBALS['activate2']=esc_attr( get_option('activate2') );
}
//print_r($GLOBALS);
?>
<div id="Quiz_msg" class="Quiz_msg"></div>	
 <table class="form-table"><div valign="top">
<tr class="sel_pp">
<th  scope="row" style="padding-left: 0px !important;">Enter Quiz Title :- </th>
<td>
    <input type="text" name="Enter_Quiz_Title" id="Enter_Quiz_Title" class="Enter_Quiz_Title" cols="200" row="1" value=""/>
</td>
</tr>
 </div></table>
<div class='image_show'>
    <img id='image_show' src='<?= wp_get_attachment_url( get_option( 'images_selector' ) ); ?>' alt=""/>
         
		</div>
 <input id="upload_quiz_image" type="button" class="upload_quiz_image button" value="<?php _e( 'Upload image' ); ?>" />&nbsp;&nbsp;
                <input type="submit" id="submit" name="submit" value="Add Quiz" class="button button-primary button-large">
                <input type='hidden' name='hidden_images' id='hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>
 

<?php
require_once 'All_Quiz.php';
  echo '</form>';
?>
<script>
function editquiz(n,quiz,event){ 
    $(".edit_quizrr").css("display","block");
    $(".addnewquiz_form").css("display","none");
    $(".edit_quizrr").find(".editquizimg").html("");
    quiz = encodeURIComponent(quiz);
    
        $.ajax({
   		type: 'GET',
   		url: "<?php echo plugins_url( 'ajax_pages/ajax_quiz_edit.php' , __FILE__ );?>",
   		data: "quiz1="+quiz,
                success: function(msg){
            var obj = $.parseJSON( msg );
           for(var i=0;i<obj.length;i++){
             
              if(obj[i]['quiz_image_name'] != null && obj[i]['quiz_title'] != null){ //alert(obj[i]['quiz_image_name']);
               $(".edit_quizrr .form-table .sel_pp").find("td").text("");
              $(".edit_quizrr .form-table .sel_pp").find("td").append('<input type="text" name="Enter_Quiz_Title" id="Enter_Quiz_Title" class="Enter_Quiz_Title edit_quiz_title" cols="70" row="1" value="'+obj[i]['quiz_title']+'"/>');
           $(".edit_quizrr").find(".editquizimg").append('<img alt="" id="editquizimg" src="'+obj[i]['quiz_image_name']+'"/>');
           $(".edit_quizrr").find("#quizhidden").text("");
           $(".edit_quizrr").find("#quizhidden").append('<span id="quizhidden" style="display:none;">'+obj[i]['quiz_title']+'</span>');
       }
}              
            
                    //$("#Quiz_msg").append('<div id="Quiz_msg" class="Quiz_msg">'+msg+'</div>');
                  // window.location.assign("/wp-admin/admin.php?page=Add_New_Quiz");
                }
               });  
       
   
   //event.preventDefault();  
}   
$(document).ready(function(){
 $(".edit_button").click(function(event){
    var editlink =  $("#editquizimg").attr("src");  
    editlink = encodeURIComponent(editlink);
    var editquiz =  $(".edit_quiz_title").val(); 
    editquiz = encodeURIComponent(editquiz);
    var quizhidden =  $("#quizhidden").text();
    quizhidden = encodeURIComponent(quizhidden);
    $.ajax({
   		type: 'GET',
   		url: "<?php echo plugins_url( 'ajax_pages/update_quiz.php' , __FILE__ );?>",
   		data: "editlink1="+editlink+"&editquiz1="+editquiz+"&quizhidden1="+quizhidden,
                success: function(msg){alert(msg);
            $("#update_quizmsg").text("");
                    $("#update_quizmsg").append('<div id="update_quizmsg" class="Quiz_msg">'+msg+'</div>');
                   window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_New_Quiz");
                }
               }); 
    event.preventDefault();  
 });
 });
</script>
<div class="edit_quizrr" id="edit_quizrr" style="display:none;">
    <span id="quizhidden" class="quizhidden" style="display:none;"></span>
<div id="update_quizmsg" class="Quiz_msg"></div>	
 <table class="form-table"><div valign="top">
<tr class="sel_pp">
<th  scope="row" style="padding-left: 0px !important;">Enter Quiz Title :- </th>
<td><input type="text" name="Enter_Quiz_Title" id="Enter_Quiz_Title" class="Enter_Quiz_Title edit_quiz_title" cols="70" row="1" value=""/></td>
</tr>
 </div></table>
<div class='editquizimg'>
    <img  id='editquizimg' src='<?= wp_get_attachment_url( get_option( 'images_selector' ) ); ?>' alt=""/>
         
		</div>
 <input id="edit_quiz_image" type="button" class="upload_quiz_image button" value="<?php _e( 'Upload image' ); ?>" />&nbsp;&nbsp;
 <input type="submit" id="submit" name="submit" value="Save Changes" class="button button-primary button-large edit_button">
                <input type='hidden' name='hidden_images' id='hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>&nbsp;&nbsp;   
                <a class="button button-primary button-large" href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_New_Quiz" name="delete"  > Back </a>
</div>
<?php                
  echo '</div>';
?>

 <script>
         $(document).ready(function(){
             //$("#addnewquiz").click(function(){
                 $(".addnewquiz_form").css("display","block");
                 $(".all_table_").css("display","block");
                  $("#addnewquiz").css("display","block")
                 
            // });
         });
</script>
<?php
}
add_action( 'admin_footer', 'quiz_media_selector' );

function quiz_media_selector() {

	$my_saved_attachment_post_id = get_option( 'images_selector', 0 );
        //print_r($my_saved_attachment_post_id);
	?><script type='text/javascript'>
//------------------------------------
$( document ).ready( function() {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			$('#edit_quiz_image').on('click', function( event ){

				event.preventDefault();
                                $(".edit_quizrr").find(".editquizimg").html("");
                         $(".edit_quizrr").find(".editquizimg").append("<img id='editquizimg' src=''/>");
				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

			
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	
				});

				
				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#editquizimg' ).attr( 'src', attachment.url ).css( 'width', '200px' );//alert(attr( 'src', attachment.url ));
					$( '#hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});
//-------------------------------------


		$( document ).ready( function( $ ) {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; // Store the old id
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; // Set this

			jQuery('#upload_quiz_image').on('click', function( event ){

				event.preventDefault();

				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

			
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false	
				});

				
				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#image_show' ).attr( 'src', attachment.url ).css( 'width', '200px' );//alert(attr( 'src', attachment.url ));
					$( '#hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});

	</script><?php
}
$GLOBALS['quesno']=esc_attr( get_option('quesno') );
for($j=1;$j<=$GLOBALS['quesno'];$j++){
 
array_push($GLOBALS, esc_attr( get_option("activa$j")));
//echo $GLOBALS['activate2']=esc_attr( get_option('activate2') );
}
//$GLOBALS['activate_quiz']=esc_attr( get_option('activate_quiz') );
for($j=1;$j<=4;$j++){
$GLOBALS["activa$j"] = esc_attr( get_option("activa$j") );
}
?>