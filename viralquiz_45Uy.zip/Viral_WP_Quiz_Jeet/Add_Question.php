<?php
add_action('admin_init', 'Add_Questions_design' );
function Add_Questions_design(){
     register_setting( 'Add_Question_option', 'enter_question' );
     register_setting( 'Add_Question_option', 'enter_question_description' );
     register_setting( 'Add_Question_option', 'Option1' );
     register_setting( 'Add_Question_option', 'Option2' );
     register_setting( 'Add_Question_option', 'Option3' );
     register_setting( 'Add_Question_option', 'Option4' );
     register_setting( 'Add_Question_option', 'Option5' );
     register_setting( 'Add_Question_option', 'Option6' );
     register_setting( 'Add_Question_option', 'Correct_Answer' );
     register_setting( 'Add_Question_option', 'enter_question_number' );
     register_setting( 'Add_Question_option', 'select_quiz' );
     register_setting( 'Add_Question_option', 'Select_Question_image' );
}
function Add_Questions_Callback(){
    if ( isset( $_POST['submit'] ) && isset( $_POST['hidden_images'] ) ) :
		update_option( 'images_selector', absint( $_POST['hidden_images'] ) );
	endif;

	wp_enqueue_media();    
?>
<link href="<?=  plugins_url('css/AddNewQuestion.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
<script src='<?php echo plugins_url('js/jquery.js',__FILE__); ?>'></script>
<style>
#Correct_Answer option {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipses;
      width: 200px;
}
.select_quiz option{width: 200px;}
</style>
 <script>
 jQuery(document).ready(function(){
     $("body").css("background-color","#F1F1F1");
     $("#submit").click(function(event){
         
                 var question_img_path = $("#image_show").attr("src");
                 question_img_path = encodeURIComponent(question_img_path);
                 var enter_question_number = $("#enter_question_number").val();
                 enter_question_number = encodeURIComponent(enter_question_number);
                 var select_quiz = $("#select_quiz").val();
                 select_quiz = encodeURIComponent(select_quiz);
                 var enter_question = $("#enter_question").val();
                 enter_question = encodeURIComponent(enter_question);
                 //alert(enter_question);
                 var enter_question_description = $("#enter_question_description").val();
                 enter_question_description = encodeURIComponent(enter_question_description);
                 var Option1 = $("#Option1").val();
                 Option1 = encodeURIComponent(Option1);
                 var Option2 = $("#Option2").val();
                 Option2 = encodeURIComponent(Option2);
                 var Option3 = $("#Option3").val();
                 Option3 = encodeURIComponent(Option3);
                 var Option4 = $("#Option4").val();
                 Option4 = encodeURIComponent(Option4);
                 var Option5 = $("#Option5").val();
                 Option5 = encodeURIComponent(Option5);
                 var Option6 = $("#Option6").val();
                 Option6 = encodeURIComponent(Option6);
                 var Correct_Answer = $("#Correct_Answer").val();
                
                 if(Correct_Answer != null){
                     Correct_Answer = encodeURIComponent(Correct_Answer);
                $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/ajax_question.php' , __FILE__ );?>',
   		data: "quiz_img_path1="+question_img_path+"&enter_question_number1="+enter_question_number+"&select_quiz1="+select_quiz+"&enter_question1="+enter_question+"&enter_question_description1="+enter_question_description+"&Option11="+Option1+"&Option21="+Option2+"&Option31="+Option3+"&Option41="+Option4+"&Option51="+Option5+"&Option61="+Option6+"&Correct_Answer1="+Correct_Answer,
                success: function(msg){
                    $("#question_msg").text("");
                    $("#question_msg").append('<div id="question_msg" class="question_msg Quiz_msg">'+msg+'</div>');
                    if(msg != null){alert(msg);
                   window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Questions");
                    }
                }
               }); }
               else{
               $("#cortmsg").text("");
               $("#cortmsg").append("Please select the correct option").css({"color":"green","font-weight":"700","font-size":"20px"});
               
               }
               event.preventDefault();
              });
         });
 </script>
<?php
     echo '<div class="wrap">
<span id="addquestion" class="addquestion" style="display: -webkit-box; display: -moz-inline-box;" ><h1> Manage Questions <button id="addnewquestion" class="page-title-action">Add New Question</button></h1></span>';
 require_once 'All_Question.php';
echo '<form class="addnewquestion_form" method="post" action="options.php">'; ?>
    <?php settings_fields( 'Add_Question_option' ); ?>
    <?php do_settings_sections( 'Add_Question_option' ); ?>
<?php
  
  $GLOBALS['enter_question']=esc_attr( get_option('enter_question') );
  $GLOBALS['enter_question_description']=esc_attr( get_option('enter_question_description') );
  $GLOBALS['Option1']=esc_attr( get_option('Option1') );
  $GLOBALS['Option2']=esc_attr( get_option('Option2') );
  $GLOBALS['Option3']=esc_attr( get_option('Option3') );
  $GLOBALS['Option4']=esc_attr( get_option('Option4') );
  $GLOBALS['Option5']=esc_attr( get_option('Option5') );
  $GLOBALS['Option6']=esc_attr( get_option('Option6') );
  $GLOBALS['Correct_Answer']=esc_attr( get_option('Correct_Answer') );
  $GLOBALS['enter_question_number']=esc_attr( get_option('enter_question_number') );
  $GLOBALS['select_quiz']=esc_attr( get_option('select_quiz') );
  $GLOBALS['Select_Question_image']=esc_attr( get_option('Select_Question_image') );
  //$questionimgurl = $_POST['question_img_path'];
?>
 <table class="form-table">
 <div id="question_msg" class="question_msg Quiz_msg"></div>
 <tr class="sel_pp">
     <th scope="row" style="padding-left: 0px !important;">Enter Question Number :- </th>
     <td><input  type="text" name="enter_question_number" id="enter_question_number" class="enter_question_number" cols="70" row="1" value="" required="required"/></td>
</tr>
<tr class="sel_pp">
<th scope="row" style="padding-left: 0px !important;">Select Quiz :- </th>
<td><select name="select_quiz" id="select_quiz" class="select_quiz" required="required"/>
<?php
global $wpdb;
$table_name = $wpdb->prefix."Quiz";
$result = $wpdb->get_results ("SELECT quiz_title FROM $table_name");
//print_r($result);
for($i=0;$i<=count($result)-1;$i++){
?>  
        <option value="<?= $result[$i]->quiz_title; ?>"<?php selected($GLOBALS['select_quiz'], $result[$i]->quiz_title );?>><?= $result[$i]->quiz_title; ?></option>
<?php } ?>        
</select></td>
</tr>
 
<tr class="sel_pp">
<th scope="row" style="padding-left: 0px !important;">Enter Question :- </th>
<td><textarea style="resize: none;" name="enter_question" id="enter_question" class="enter_question" cols="70" row="1" value="" required="required"/></textarea></td>
</tr> 

 <tr class="sel_pp">
<th scope="row"  style="padding-left: 0px !important;">Enter Question Description :- </th>
<td><textarea style="resize: none;" name="enter_question_description" id="enter_question_description" class="enter_question_description" cols="70" row="1" value=""/></textarea></th>
</tr> 

<tr class="sel_pp">             
    <th scope="row"  style="padding-left: 0px !important;">Enter Optional Answers :- </th>
    <td class="optans">             
                 <strong style="color:#800000;">No need to fill all fields. Fill only required field.</strong><br><br>
                 <label>Option1</label><br>
        <textarea name="Option1" id="Option1" class="Option1" cols="50" row="1" value="" required="required"/></textarea><br><br>
                 <label>Option2</label><br>
        <textarea name="Option2" id="Option2" class="Option2" cols="50" row="1" value="" required="required"/></textarea><br><br>
                 <label>Option3</label><br>
       <textarea name="Option3" id="Option3" class="Option3" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Option4</label><br>
        <textarea name="Option4" id="Option4" class="Option4" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Option5</label><br>
        <textarea name="Option5" id="Option5" class="Option5" cols="50" row="1" value=""/></textarea><br><br>
                <label>Option6</label><br>
        <textarea name="Option6" id="Option6" class="Option6" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Select Correct Answer</label><br>
                 <select id="Correct_Answer" class="form-control" name="Correct_Answer" style="width:357px;height:40px;" required>   
                 <option>-</option></select>
                 <span id="cortmsg"> </span>
</td>          
        </tr>
        </table>
<div class='image_show'>
			<img id='image_show' src='<?php echo wp_get_attachment_url( get_option( 'images_selector' ) ); ?>' alt="">
		</div>
 <input id="upload_question_image" type="button" class="btnsubque button" value="<?php _e( 'Upload image' ); ?>" />&nbsp;&nbsp;		
                <input type="submit" id="submit" name="submit" value="Save Changes" class="button button-primary button-large"> 
                <input type='hidden' name='hidden_images' id='hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>

<?php
  echo '</form></div> ';
?>
<script>
function editquestion(n,question,question_number,event){
    $("#question_edit").css("display","block");
    $(".wrap").css("display","none");
    $("#question_edit").find("#hidden_question").text("");
    $("#question_edit").find("#hidden_question_no").text("");
    $("#question_edit").find("#hidden_question").append('<span id="hidden_question" class="hidden_question" style="display:none;">'+question+'</span>');
    $("#question_edit").find("#hidden_question_no").append('<span id="hidden_question_no" class="hidden_question_no" style="display:none;">'+question_number+'</span>');
    //alert(n);alert(question);alert(question_number);
    question = encodeURIComponent(question);
    question_number = encodeURIComponent(question_number);
    $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/ajax_question_edit.php' , __FILE__ );?>',
   		data: "question1="+question+"&question_number1="+question_number,
                success: function(msg){
                    //alert(msg);
                    var obj = $.parseJSON( msg );
                    for(var i=0;i<obj.length;i++){
                     $(".question_edit .form-table .equesno td").find("#enter_question_number").val(obj[i]['question_number']);   
                     $(".question_edit .form-table .sequesquiz td #select_quiz").find("option[value='"+obj[i]['quiz_name']+"']").attr("selected", true);
                     //$(".question_edit .form-table .sequesquiz td").find("#select_quiz").append('<option value="'+obj[i]['quiz_name']+'">'+obj[i]['quiz_name']+'</option> ');   
                     $(".question_edit .form-table .eques td").find("#enter_question").val(obj[i]['question']);
                     $(".question_edit .form-table .equesdesc td").find("#enter_question_description").val(obj[i]['question_description']);
                     $(".question_edit .form-table .eansopt td").find("#Option1").val(obj[i]['option1']);
                     $(".question_edit .form-table .eansopt td").find("#Option2").val(obj[i]['option2']);
                     $(".question_edit .form-table .eansopt td").find("#Option3").val(obj[i]['option3']);
                     $(".question_edit .form-table .eansopt td").find("#Option4").val(obj[i]['option4']);
                     $(".question_edit .form-table .eansopt td").find("#Option5").val(obj[i]['option5']);
                     $(".question_edit .form-table .eansopt td").find("#Option6").val(obj[i]['option6']);
                     
                     $(".question_edit .questimgedit").find("img").attr("src", obj[i]['question_image_name']);
                     $("#hidden_correctans").html(obj[i]['correct_answer']);
                       }          
                       sd();
             }
               }); 
              
              
                 //event.preventDefault();
}

function sd(){
//$(document).ready(function(){
//$("#Correct_Answer_edit").focus(function(){
$(".editcortans").text("");
                 var editarr =[];
                 var vrtt;
                 $("tr .optansed textarea").each(function(){ 
                     if($(this).val() !=null && $(this).val().length > 0)
                     {
                       
                         editarr.push($(this).val());
                         
                     }
                 });
                   $('.editcortans').append("<option value=''></option>");
                              for (var i = 0; i < editarr.length; i++)                             
                        { 
                             if(editarr[i].length >= 51){
                             var fortyWords = editarr[i].substr(0,51);
                             $('.editcortans').append($('<option>',
                             {
                              value: editarr[i],
                              text : fortyWords 
                              }));
                        }
                        else if(editarr[i].length < 51){
                             $('.editcortans').append($('<option>',
                             {
                              value: editarr[i],
                              text : editarr[i] 
                              }));
                        }
                         }
                         var hidden_correctans = $("#hidden_correctans").text();
                         //alert($(".editcortans").find("option[value='"+hidden_correctans+"']").attr("selected", true));
                         $(".editcortans").find("option[value='"+hidden_correctans+"']").attr("selected", true);
                   //  });
                    // });
             }
//function sd(){
$(document).ready(function(){
$("#Correct_Answer_edit").focus(function(){
$(".editcortans").text("");
                 var editarr =[];
                 var vrtt;
                 $("tr .optansed textarea").each(function(){ 
                     if($(this).val() !=null && $(this).val().length > 0)
                     {
                       
                         editarr.push($(this).val());
                         
                     }
                 });
                   $('.editcortans').append("<option value=''></option>");
                              for (var i = 0; i < editarr.length; i++)                             
                        { 
                             if(editarr[i].length >= 51){
                             var fortyWords = editarr[i].substr(0,51);
                             $('.editcortans').append($('<option>',
                             {
                              value: editarr[i],
                              text : fortyWords 
                              }));
                        }
                        else if(editarr[i].length < 51){
                             $('.editcortans').append($('<option>',
                             {
                              value: editarr[i],
                              text : editarr[i] 
                              }));
                        }
                         }
                         var hidden_correctans = $("#hidden_correctans").text();
                         //alert($(".editcortans").find("option[value='"+hidden_correctans+"']").attr("selected", true));
                         $(".editcortans").find("option[value='"+hidden_correctans+"']").attr("selected", true);
                     });
                     });
           //  }

                         
$(document).ready(function(){
 $(".question_edit_button").click(function(event){
    var hidden_question = $(".question_edit").find("#hidden_question").text(); 
    hidden_question = encodeURIComponent(hidden_question);
    var hidden_question_no = $(".question_edit").find("#hidden_question_no").text();
    hidden_question_no = encodeURIComponent(hidden_question_no);
    var enter_question_number = $(".question_edit .form-table .equesno td").find("#enter_question_number").val();
    enter_question_number = encodeURIComponent(enter_question_number);
    var select_quiz = $(".question_edit .form-table .sequesquiz td").find("#select_quiz").val();
    select_quiz = encodeURIComponent(select_quiz);
    var enter_question = $(".question_edit .form-table .eques td").find("#enter_question").val();
    enter_question = encodeURIComponent(enter_question);
    var enter_question_description = $(".question_edit .form-table .equesdesc td").find("#enter_question_description").val();
    enter_question_description = encodeURIComponent(enter_question_description);
    var Option1 = $(".question_edit .form-table .eansopt td").find("#Option1").val();
    Option1 = encodeURIComponent(Option1);
    var Option2 = $(".question_edit .form-table .eansopt td").find("#Option2").val();
    Option2 = encodeURIComponent(Option2);
    var Option3 = $(".question_edit .form-table .eansopt td").find("#Option3").val();
    Option3 = encodeURIComponent(Option3);
    var Option4 = $(".question_edit .form-table .eansopt td").find("#Option4").val();
    Option4 = encodeURIComponent(Option4);
    var Option5 = $(".question_edit .form-table .eansopt td").find("#Option5").val();
    Option5 = encodeURIComponent(Option5);
    var Option6 = $(".question_edit .form-table .eansopt td").find("#Option6").val();
    Option6 = encodeURIComponent(Option6);
    var Correct_Answer_opt = $(".question_edit .form-table .eansopt").find(".editcortans").val();
    //alert(Correct_Answer_opt.length);
    //alert(Correct_Answer_opt != null);
    if(Correct_Answer_opt != null && Correct_Answer_opt.length > 0){
        Correct_Answer_opt = encodeURIComponent(Correct_Answer_opt);
    var questimgedit = $(".question_edit .questimgedit").find("img").attr("src");
        questimgedit = encodeURIComponent(questimgedit);
     $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/update_question.php' , __FILE__ );?>',
   		data: "questimgedit1="+questimgedit+"&enter_question_number1="+enter_question_number+"&select_quiz1="+select_quiz+"&enter_question1="+enter_question+"&enter_question_description1="+enter_question_description+"&Option11="+Option1+"&Option21="+Option2+"&Option31="+Option3+"&Option41="+Option4+"&Option51="+Option5+"&Option61="+Option6+"&Correct_Answer_opt1="+Correct_Answer_opt+"&hidden_question1="+hidden_question+"&hidden_question_no1="+hidden_question_no,
                success: function(msg){
                    alert(msg);
                     window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Questions");
                    }
               });
               }
               else{
               $("#cortmsg12").text("");
               $("#cortmsg12").append("Please select the correct option").css({"color":"green","font-weight":"700","font-size":"20px"});
               //alert("Please select the correct option");
               }
               event.preventDefault();
 });
});
</script>
<div id="question_edit" class="question_edit" style="display:none;font-size: 23px;font-weight: 400;margin: 0;padding: 9px 15px 4px 0;line-height: 29px;"> 
    <span id="hidden_correctans" class="hidden_correctans" style="display:none;"></span><span id="hidden_question" class="hidden_question" style="display:none;"></span> <span id="hidden_question_no" class="hidden_question_no" style="display:none;"></span>
<span id="addquestion" class="addquestion" style="display: -webkit-box; display: -moz-inline-box;" ><h1 style="font-size: 23px;font-weight: 400;margin: 0;padding: 9px 15px 4px 0;line-height: 29px;">Edit Question</h1></span>                
 
<table class="form-table">
 <div id="question_msg" class="question_msg Quiz_msg"></div>
 <tr class="sel_pp equesno">
     <th scope="row" style="padding-left: 0px !important;">Enter Question Number :- </th>
    <td><input type="text" name="enter_question_number" id="enter_question_number" class="enter_question_number" cols="70" row="1" value="" required="required"/></td>
</tr>
<tr class="sel_pp sequesquiz">
<th scope="row" style="padding-left: 0px !important;">Select Quiz :- </th>
<td><select name="select_quiz" id="select_quiz" class="select_quiz" required="required"/>
        <?php
global $wpdb;
$table_name = $wpdb->prefix."Quiz";
$result = $wpdb->get_results ("SELECT quiz_title FROM $table_name");
//print_r($result);
for($i=0;$i<=count($result)-1;$i++){
?>  
<option id="dataquiz" class="dataquiz" value="<?= $result[$i]->quiz_title; ?>"<?php selected($GLOBALS['select_quiz'], $result[$i]->quiz_title );?>><?= $result[$i]->quiz_title; ?></option>
<?php } ?>  
</select></td>
</tr>
 
<tr class="sel_pp eques">
<th scope="row" style="padding-left: 0px !important;">Enter Question :- </th>
<td><textarea style="resize: none;" name="enter_question" id="enter_question" class="enter_question" cols="70" row="1" value="" required="required"/></textarea></td>
</tr> 

 <tr class="sel_pp equesdesc">
<th scope="row"  style="padding-left: 0px !important;">Enter Question Description :- </th>
<td><textarea style="resize: none;" name="enter_question_description" id="enter_question_description" class="enter_question_description" cols="70" row="1" value=""/></textarea></th>
</tr> 

<tr class="sel_pp eansopt">             
    <th scope="row"  style="padding-left: 0px !important;">Enter Optional Answers :- </th>
    <td class="optansed">             
                 <strong style="color:#800000;">No need to fill all fields. Fill only required field.</strong><br><br>
                 <label>Option1</label><br>
        <textarea name="Option1" id="Option1" class="Option1" cols="50" row="1" value="" required="required"/></textarea><br><br>
                 <label>Option2</label><br>
        <textarea name="Option2" id="Option2" class="Option2" cols="50" row="1" value="" required="required"/></textarea><br><br>
                 <label>Option3</label><br>
       <textarea name="Option3" id="Option3" class="Option3" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Option4</label><br>
        <textarea name="Option4" id="Option4" class="Option4" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Option5</label><br>
        <textarea name="Option5" id="Option5" class="Option5" cols="50" row="1" value=""/></textarea><br><br>
                <label>Option6</label><br>
        <textarea name="Option6" id="Option6" class="Option6" cols="50" row="1" value=""/></textarea><br><br>
                 <label>Select Correct Answer</label><br>
                 <select id="Correct_Answer_edit" class="form-control editcortans" name="Correct_Answer" style="width:357px;height:40px;" required>   
                     <option value="" id="Correct_Answer_opt" class="Correct_Answer_opt"></option>                 
                 </select>
                 <span id="cortmsg12"> </span>
</td>          
        </tr>
        </table>
<div class='questimgedit'>
			<img id='questimgedit' src='<?php echo wp_get_attachment_url( get_option( 'images_selector' ) ); ?>' alt="">
		</div>
		<input id="edit_question_image" type="button" class="btnsubque button" value="<?php _e( 'Upload image' ); ?>" />&nbsp;&nbsp;		
                <input type="submit" id="submit" name="submit" value="Save Changes" class="button button-primary button-large question_edit_button">&nbsp;&nbsp; 
                <input type='hidden' name='hidden_images' id='hidden_images' value='<?php echo get_option( 'images_selector' ); ?>'>
    <a id="questionback" href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_Questions" class="button button-primary button-large" name="questiondelete"> Back </a>
           
</div>                
                        
 <script>
         $(document).ready(function(){
             $("#addnewquestion").click(function(){
                 $(".addnewquestion_form").css("display","block")
                 $(".all_table_").css("display","none");
             });
             $("#Correct_Answer").text("");
             $("#Correct_Answer").focus(function(){
                 $("#Correct_Answer").text("");
                 var arr =[];
                 var vrtt;
                 $(".optans textarea").each(function(){ 
                     if($(this).val() !=null && $(this).val().length > 0)
                     {
                       
                         arr.push($(this).val());
                         
                     }
                 });
                   $('#Correct_Answer').append("<option>-</option>");
                              for (var i = 0; i < arr.length; i++)                             
                        { 
                             if(arr[i].length >= 51){
                             var fortyWords = arr[i].substr(0,51);
                             $('#Correct_Answer').append($('<option>',
                             {
                              value: arr[i],
                              text : fortyWords 
                              }));
                        }
                        else if(arr[i].length < 51){
                             $('#Correct_Answer').append($('<option>',
                             {
                              value: arr[i],
                              text : arr[i] 
                              }));
                        }
                         }
             });
         });
 </script>
 <?php
 }
 add_action( 'admin_footer', 'question_media_selector' );

function question_media_selector() {

	$my_saved_attachment_post_id = get_option( 'images_selector', 0 );

	?><script type='text/javascript'>
//-------------------------------------------

		jQuery( document ).ready( function( $ ) {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; 
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; 

			jQuery('#edit_question_image').on('click', function( event ){

				event.preventDefault();

				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

				
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false
				});

				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#questimgedit' ).attr( 'src', attachment.url ).css( 'width', '200px' );
					$( '#hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});

//-------------------------------------------

		jQuery( document ).ready( function( $ ) {

			var file_frame;
			var wp_media_post_id = wp.media.model.settings.post.id; 
			var set_to_post_id = <?php echo $my_saved_attachment_post_id; ?>; 

			jQuery('#upload_question_image').on('click', function( event ){

				event.preventDefault();

				if ( file_frame ) {
					
					file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
					
					file_frame.open();
					return;
				} else {
					
					wp.media.model.settings.post.id = set_to_post_id;
				}

				
				file_frame = wp.media.frames.file_frame = wp.media({
					title: 'Select a image to upload',
					button: {
						text: 'Use this image',
					},
					multiple: false
				});

				file_frame.on( 'select', function() {
					
					attachment = file_frame.state().get('selection').first().toJSON();

					$( '#image_show' ).attr( 'src', attachment.url ).css( 'width', '200px' );
					$( '#hidden_images' ).val( attachment.id );

					wp.media.model.settings.post.id = wp_media_post_id;
				});

					file_frame.open();
			});

			jQuery( 'a.add_media' ).on( 'click', function() {
				wp.media.model.settings.post.id = wp_media_post_id;
			});
		});

	</script><?php
}
 ?>