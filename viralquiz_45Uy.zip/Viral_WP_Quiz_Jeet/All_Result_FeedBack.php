<?php
global $wpdb;
$table_name = $wpdb->prefix."Result";
$result_result = $wpdb->get_results ("SELECT * FROM $table_name");

?> 
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link href="<?= plugins_url('css/bootstrap.min.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
<table class="table-striped table-hover result_table">
    <script>
  function deleteresult(n,event){   
       var del = confirm("Press ok and delete this result.");
                   if (del == true){ 
                 var resudelet =$(".quwstion_action_heading").find("#resultdelete"+n).attr("title");//alert(resudelet);
                resudelet = encodeURIComponent(resudelet);
                 $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/result_delete.php' , __FILE__ );?>',
   		data: "resudelet1="+resudelet,
                success: function(msg){
                  alert(msg);
                  window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Result");
                }
               });  
               }
               //event.preventDefault();
              }
 </script>
  <thead>
    <tr>
      <th class="question_no_theading">Quiz Score</th>
      
      <th class="question_theading">Feedback</th>      
      <th class="question_Action_theading">Action to be Taken</th>
      
    </tr>
  </thead>
  <tbody>
       <?php   for($i=0;$i<=count($result_result)-1;$i++){?>
    <tr>
      <td class="quiz_score_heading"><?= $result_result[$i]->score; ?></td>
      
      <td class="quiz_feed_heading"><?= $result_result[$i]->score_statement; ?></td>
      <td class="quwstion_action_heading">
          <a href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_Result" id="resultdelete<?= $i ?>" onclick="deleteresult('<?= $i ?>')" class="btn btn-danger btn-xs questiondelete" name="resultdelete" title="<?= $result_result[$i]->score; ?>"><span class="glyphicon glyphicon-trash"></span> DELETE</a>
          <a id="resultedit<?= $i ?>" onclick="editresult('<?= $i ?>','<?= $result_result[$i]->result_quiz_name; ?>','<?= $result_result[$i]->score; ?>','<?= $result_result[$i]->score_statement; ?>')" class="btn btn-success btn-lg editbtn" name="resultdelete" title="<?= $result_result[$i]->score; ?>"><span class="glyphicon glyphicon-edit"></span> EDIT</a>
      
      </td>
     
    </tr>
    <?php 
    } 
    ?> 
  </tbody>
</table> 