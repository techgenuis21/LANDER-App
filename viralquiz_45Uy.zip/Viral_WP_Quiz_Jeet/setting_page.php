<?php
     $activate_quiz='';
     $htitle='';
     $discription='';
     $mm='';
     $ss='';
     $enable='';
     $countdown='';
     $minimum_score='';
     $Price_button_text='';
     $Button_color='';
     $Button_text_color='';
     $Price_url='';
     $backc='';
     $fontc='';
     $Quizcfbold='';
     $Quizcfitalic='';
     $Quizcfuline='';
     $Quizfontsaz='';
     $hfontc='';
     $cfbold='';
     $cfitalic='';
     $cfuline='';
     $fontsaz='';
     $backcoq='';
     $backcooa='';
     $backcoqf='';
     $backcooaf='';
     $cfqbold='';
     $cfqitalic='';
     $cfquline='';
     $qfontsaz='';
     $cfoabold='';
     $cfoaitalic='';
     $cfoaquline='';
     $oafontsaz='';
     $ansbackcoq='';
     $ansbackcof='';
     $anscfoabold='';
     $anscfoaitalic='';
     $anscfoaquline='';
     $ansoafontsaz='';
     
     $nextbutton_background_color='';
     $nextbutton_font_color='';
     $nextbutton_font_size='';
     $resultbutton_background_color='';
     $resultbutton_font_color='';
     $resultbutton_font_size='';
   
add_action('admin_menu', 'quize_contest_setting');
function quize_contest_setting(){

    add_menu_page('Viral WP Quiz Jeet', 'Viral WP Quiz Jeet', 'administrator', 'Quiz_Contest_page', 'Quiz_Contest_design_page', plugins_url( 'images/icon.png' , __FILE__ ) );
        add_submenu_page('Quiz_Contest_page', 'Manage Quiz', 'Manage Quiz', 'administrator', 'Add_New_Quiz', 'Add_New_Quiz_Callback');
        add_submenu_page('Quiz_Contest_page', 'Manage Questions', 'Manage Questions', 'administrator', 'Add_Questions', 'Add_Questions_Callback');
        add_submenu_page('Quiz_Contest_page', 'Manage Result', 'Manage Result', 'administrator', 'Add_Result', 'Add_Result_Callback');
   
}
add_action('admin_init', 'Quiz_Contest_design' );
function Quiz_Contest_design(){
   register_setting( 'Quiz_Contest_option', 'activate_quiz' );
   register_setting( 'Quiz_Contest_option', 'htitle' );
   register_setting( 'Quiz_Contest_option', 'discription' );
   register_setting( 'Quiz_Contest_option', 'mm' );
   register_setting( 'Quiz_Contest_option', 'ss' );
   register_setting( 'Quiz_Contest_option', 'enable' );
   register_setting( 'Quiz_Contest_option', 'countdown' );
   
   register_setting( 'Quiz_Contest_option', 'minimum_score' );
   register_setting( 'Quiz_Contest_option', 'Price_button_text' );
   register_setting( 'Quiz_Contest_option', 'Button_color' );
   register_setting( 'Quiz_Contest_option', 'Button_text_color' );
   register_setting( 'Quiz_Contest_option', 'Price_url' );
       
   register_setting( 'Quiz_Contest_option', 'backc' );
   register_setting( 'Quiz_Contest_option', 'fontc' );
   register_setting( 'Quiz_Contest_option', 'Quizcfbold' );
   register_setting( 'Quiz_Contest_option', 'Quizcfitalic' );
   register_setting( 'Quiz_Contest_option', 'Quizcfuline' );
   register_setting( 'Quiz_Contest_option', 'Quizfontsaz' );
   register_setting( 'Quiz_Contest_option', 'hfontc' );
   register_setting( 'Quiz_Contest_option', 'cfbold' );
   register_setting( 'Quiz_Contest_option', 'cfitalic' );
   register_setting( 'Quiz_Contest_option', 'cfuline' );
   register_setting( 'Quiz_Contest_option', 'fontsaz' );
   register_setting( 'Quiz_Contest_option', 'backcoq' );
   register_setting( 'Quiz_Contest_option', 'backcooa' );
   register_setting( 'Quiz_Contest_option', 'backcoqf' );
   register_setting( 'Quiz_Contest_option', 'backcooaf' );
   register_setting( 'Quiz_Contest_option', 'cfqbold' );
   register_setting( 'Quiz_Contest_option', 'cfqitalic' );
   register_setting( 'Quiz_Contest_option', 'cfquline' );
   register_setting( 'Quiz_Contest_option', 'qfontsaz' );
   register_setting( 'Quiz_Contest_option', 'cfoabold' );
   register_setting( 'Quiz_Contest_option', 'cfoaitalic' );
   register_setting( 'Quiz_Contest_option', 'cfoaquline' );
   register_setting( 'Quiz_Contest_option', 'oafontsaz' );
   register_setting( 'Quiz_Contest_option', 'ansbackcoq' );
   register_setting( 'Quiz_Contest_option', 'ansbackcof' );
   register_setting( 'Quiz_Contest_option', 'anscfoabold' );
   register_setting( 'Quiz_Contest_option', 'anscfoaitalic' );
   register_setting( 'Quiz_Contest_option', 'anscfoaquline' );
   register_setting( 'Quiz_Contest_option', 'ansoafontsaz' );
   
   register_setting( 'Quiz_Contest_option', 'nextbutton_background_color' );
   register_setting( 'Quiz_Contest_option', 'nextbutton_font_color' );
   register_setting( 'Quiz_Contest_option', 'nextbutton_font_size' );
   register_setting( 'Quiz_Contest_option', 'resultbutton_background_color' );
   register_setting( 'Quiz_Contest_option', 'resultbutton_font_color' );
   register_setting( 'Quiz_Contest_option', 'resultbutton_font_size' );
}
require_once 'Add_New_Quiz.php';
require_once 'Add_Question.php';
require_once 'Add_Result.php';
      
function Quiz_Contest_design_page($gl){
?>    
<div class="wrap">
<h1>Viral WP Quiz Jeet</h1><form method="post" action="options.php">
    <?php settings_fields( 'Quiz_Contest_option' ); ?>
    <?php do_settings_sections( 'Quiz_Contest_option' ); ?>
    <?php 
    $GLOBALS['activate_quiz']=esc_attr( get_option('activate_quiz') );
    $GLOBALS['htitle']=esc_attr( get_option('htitle') );
    $GLOBALS['discription']=esc_attr( get_option('discription') );
    $GLOBALS['mm']=esc_attr( get_option('mm') );
    $GLOBALS['ss']=esc_attr( get_option('ss') );
    $GLOBALS['enable']=esc_attr( get_option('enable') );
    $GLOBALS['countdown']=esc_attr( get_option('countdown') );
    $GLOBALS['minimum_score']=esc_attr( get_option('minimum_score') );
    $GLOBALS['Price_button_text']=esc_attr( get_option('Price_button_text') );
    $GLOBALS['Button_color']=esc_attr( get_option('Button_color') );
    $GLOBALS['Button_text_color']=esc_attr( get_option('Button_text_color') );
    $GLOBALS['Price_url']=esc_attr( get_option('Price_url') );
    $GLOBALS['backc']=esc_attr( get_option('backc') );
    $GLOBALS['fontc']=esc_attr( get_option('fontc') );
    $GLOBALS['Quizcfbold']=esc_attr( get_option('Quizcfbold') );
    $GLOBALS['Quizcfitalic']=esc_attr( get_option('Quizcfitalic') );
    $GLOBALS['Quizcfuline']=esc_attr( get_option('Quizcfuline') );
    $GLOBALS['Quizfontsaz']=esc_attr( get_option('Quizfontsaz') );
    $GLOBALS['hfontc']=esc_attr( get_option('hfontc') );
    $GLOBALS['cfbold']=esc_attr( get_option('cfbold') );
    $GLOBALS['cfitalic']=esc_attr( get_option('cfitalic') );
    $GLOBALS['cfuline']=esc_attr( get_option('cfuline') );
    $GLOBALS['fontsaz']=esc_attr( get_option('fontsaz') );
    $GLOBALS['backcoq']=esc_attr( get_option('backcoq') );
    $GLOBALS['backcooa']=esc_attr( get_option('backcooa') );
    $GLOBALS['backcoqf']=esc_attr( get_option('backcoqf') );
    $GLOBALS['backcooaf']=esc_attr( get_option('backcooaf') );
    $GLOBALS['cfqbold']=esc_attr( get_option('cfqbold') );
    $GLOBALS['cfqitalic']=esc_attr( get_option('cfqitalic') );
    $GLOBALS['cfquline']=esc_attr( get_option('cfquline') );
    $GLOBALS['qfontsaz']=esc_attr( get_option('qfontsaz') );
    $GLOBALS['cfoabold']=esc_attr( get_option('cfoabold') );
    $GLOBALS['cfoaitalic']=esc_attr( get_option('cfoaitalic') );
    $GLOBALS['cfoaquline']=esc_attr( get_option('cfoaquline') );
    $GLOBALS['oafontsaz']=esc_attr( get_option('oafontsaz') );
    $GLOBALS['ansbackcoq']=esc_attr( get_option('ansbackcoq') );
    $GLOBALS['ansbackcof']=esc_attr( get_option('ansbackcof') );
    $GLOBALS['anscfoabold']=esc_attr( get_option('anscfoabold') );
    $GLOBALS['anscfoaitalic']=esc_attr( get_option('anscfoaitalic') );
    $GLOBALS['anscfoaquline']=esc_attr( get_option('anscfoaquline') );
    $GLOBALS['ansoafontsaz']=esc_attr( get_option('ansoafontsaz') );
    
    $GLOBALS['nextbutton_background_color']=esc_attr( get_option('nextbutton_background_color') );
    $GLOBALS['nextbutton_font_color']=esc_attr( get_option('nextbutton_font_color') );
    $GLOBALS['nextbutton_font_size']=esc_attr( get_option('nextbutton_font_size') );
    $GLOBALS['resultbutton_background_color']=esc_attr( get_option('resultbutton_background_color') );
    $GLOBALS['resultbutton_font_color']=esc_attr( get_option('resultbutton_font_color') );
    $GLOBALS['resultbutton_font_size']=esc_attr( get_option('resultbutton_font_size') );
?>
    <table class="form-table">
      
<?php
global $wpdb;
$table_name = $wpdb->prefix."Quiz";
$result = $wpdb->get_results ("SELECT quiz_title FROM $table_name");
?>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Enter Title :- </th>
        <td><textarea name="htitle" id="htitle" class="htitle" cols="70" row="1" value="<?= $GLOBALS['htitle']; ?>"/><?= $GLOBALS['htitle']; ?></textarea></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Enter Description :- </th>
        <td><textarea name="discription" id="discription" class="discription" cols="70" row="1" value="<?= $GLOBALS['discription']; ?>"/><?= $GLOBALS['discription']; ?></textarea></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Set Time Duration :- </th>
        <td><select name="mm" id="mm" class="mm">
                <option value="0">mm</option>
<?php
                for($i=1;$i<=59;$i++){?>
                <option value="<?= $i; ?>"<?php selected($GLOBALS['mm'], $i); ?>><?= $i; ?></option>
<?php }?>
                
            </select> :
            <select name="ss" id="ss" class="ss">
                <option value="0">ss</option>
<?php
                for($j=1;$j<=59;$j++){?>
                <option value="<?= $j; ?>"<?php selected($GLOBALS['ss'], $j); ?>><?= $j; ?></option>
<?php }?>
                
            </select></td>
            </tr>
            
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick and allow user to proceed :- </th>
        <td><input type="checkbox" name="enable" id="enable" class="enable" value="true"<?php checked($GLOBALS['enable'], "true"); ?>/> (Allow user to attempt the next question irrespective of answering or not the current question.)</td>
            </tr>
            
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick and allow user to set time :- </th>
        <td><input type="checkbox" name="countdown" id="countdown" class="countdown" value="true"<?php checked($GLOBALS['countdown'], "true"); ?>/> (Allow user to set a countdown timer.)  </td>
            </tr>
            <tr><td colspan="2"> <h1> Prize winner settings</h1><td></tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Minimum Score :- </th>
        <td><input type="text" name="minimum_score" id="minimum_score" class="minimum_score" value="<?= $GLOBALS['minimum_score']; ?>"/>  For Ex:- 8 (If minimum 8 answers are correct)</td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Insert Text for Prize Button :- </th>
        <td><input type="text" name="Price_button_text" id="Price_button_text" class="Price_button_text" value="<?= $GLOBALS['Price_button_text']; ?>"/></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Button Color :- </th>
        <td><input type="text" name="Button_color" id="Button_color" class="Button_color" value="<?= $GLOBALS['Button_color']; ?>"/></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select the font color :- </th>
        <td><input type="text" name="Button_text_color" id="Button_text_color" class="Button_text_color" value="<?= $GLOBALS['Button_text_color']; ?>"/></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Insert URL to claim prize :- </th>
        <td><input type="text" name="Price_url" id="Price_url" class="Price_url" value="<?= $GLOBALS['Price_url']; ?>"/></td>
            </tr>
            
            <tr><td colspan="2"> <h1> Quiz Cover Page</h1><td></tr>
            
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Background Color :- </th>
        <td><input type="text" name="backc" id="backc" class="backc" value="<?= $GLOBALS['backc']; ?>"/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Subtitle Font Color :- </th>
        <td><input type="text" name="fontc" id="fontc" class="fontc" value="<?= $GLOBALS['fontc']; ?>"/></td>
            </tr>
            
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Subtitle in Bold :- </th>
        <td><input type="checkbox" name="Quizcfbold" id="Quizcfbold" class="Quizcfbold" value="bold"<?php checked($GLOBALS['Quizcfbold'], "bold" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Subtitle in Italics :- </th>
        <td><input type="checkbox" name="Quizcfitalic" id="Quizcfitalic" class="Quizcfitalic" value="italic"<?php checked($GLOBALS['Quizcfitalic'], "italic" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick to Underline :- </th>
        <td><input type="checkbox" name="Quizcfuline" id="Quizcfuline" class="Quizcfuline" value="underline"<?php checked($GLOBALS['Quizcfuline'], "underline" );?>/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Size :- </th>
        <td><select name="Quizfontsaz" id="Quizfontsaz" class="Quizfontsaz"/>
            <?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['Quizfontsaz'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
            
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Title Font Color :- </th>
        <td><input type="text" name="hfontc" id="hfontc" class="hfontc" value="<?= $GLOBALS['hfontc']; ?>"/></td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Title in Bold :- </th>
        <td><input type="checkbox" name="cfbold" id="cfbold" class="cfbold" value="bold"<?php checked($GLOBALS['cfbold'], "bold" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Title in Italics :- </th>
        <td><input type="checkbox" name="cfitalic" id="cfitalic" class="cfitalic" value="italic"<?php checked($GLOBALS['cfitalic'], "italic" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick to Underline :- </th>
        <td><input type="checkbox" name="cfuline" id="cfuline" class="cfuline" value="underline"<?php checked($GLOBALS['cfuline'], "underline" );?>/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Size :- </th>
        <td><select name="fontsaz" id="fontsaz" class="fontsaz"/>
            <?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['fontsaz'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
       
            <tr><td colspan="2"> <h1> Quiz Page Settings</h1><td></tr> 
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Quiz Page Background Color:-</th>
        <td><input type="text" name="backcoq" id="backcoq" class="backcoq" value="<?= $GLOBALS['backcoq']; ?>"/></td>
            </tr>
             <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Color :-</th>
        <td><input type="text" name="backcoqf" id="backcoqf" class="backcoqf" value="<?= $GLOBALS['backcoqf']; ?>"/></td>
            </tr>
          
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Question in Bold:- </th>
        <td><input type="checkbox" name="cfqbold" id="cfqbold" class="cfqbold" value="bold"<?php checked($GLOBALS['cfqbold'], "bold" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Question in Italics :- </th>
        <td><input type="checkbox" name="cfqitalic" id="cfqitalic" class="cfqitalic" value="italic"<?php checked($GLOBALS['cfqitalic'], "italic" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick to Underline :- </th>
        <td><input type="checkbox" name="cfquline" id="cfquline" class="cfquline" value="underline"<?php checked($GLOBALS['cfquline'], "underline" );?>/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Size :- </th>
        <td><select name="qfontsaz" id="qfontsaz" class="qfontsaz"/>
<?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['qfontsaz'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
             <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Background Color :-</th>
        <td><input type="text" name="backcooa" id="backcooa" class="backcooa" value="<?= $GLOBALS['backcooa']; ?>"/>    (Click to select the background color of the answers options.)</td>
            </tr>
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Color of Options :-</th>
        <td><input type="text" name="backcooaf" id="backcooaf" class="backcooaf" value="<?= $GLOBALS['backcooaf']; ?>"/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Options in Bold :- </th>
        <td><input type="checkbox" name="cfoabold" id="cfoabold" class="cfoabold" value="bold"<?php checked($GLOBALS['cfoabold'], "bold" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Options in Italics :- </th>
        <td><input type="checkbox" name="cfoaitalic" id="cfoaitalic" class="cfoaitalic" value="italic"<?php checked($GLOBALS['cfoaitalic'], "italic" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick to Underline :- </th>
        <td><input type="checkbox" name="cfoaquline" id="cfoaquline" class="cfoaquline" value="underline"<?php checked($GLOBALS['cfoaquline'], "underline" );?>/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Options Font Size :- </th>
        <td><select name="oafontsaz" id="oafontsaz" class="oafontsaz"/>
<?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['oafontsaz'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
            
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Next Button Background Color :-</th>
        <td><input type="text" name="nextbutton_background_color" id="nextbutton_background_color" class="nextbutton_background_color" value="<?= $GLOBALS['nextbutton_background_color']; ?>"/>    (Click to select the background color of the next button.)</td>
            </tr>
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Next Button Background Color :-</th>
        <td><input type="text" name="nextbutton_font_color" id="nextbutton_font_color" class="nextbutton_font_color" value="<?= $GLOBALS['nextbutton_font_color']; ?>"/>    (Click to select the font color of the next button.)</td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;"> Font Size of Next Button :- </th>
        <td><select name="nextbutton_font_size" id="nextbutton_font_size" class="nextbutton_font_size"/>
<?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['nextbutton_font_size'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
            
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Result Button Background Color :-</th>
        <td><input type="text" name="resultbutton_background_color" id="resultbutton_background_color" class="resultbutton_background_color" value="<?= $GLOBALS['nextbutton_background_color']; ?>"/>    (Click to select the background color of the result button.)</td>
            </tr>
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Result Button Background Color :-</th>
        <td><input type="text" name="resultbutton_font_color" id="resultbutton_font_color" class="resultbutton_font_color" value="<?= $GLOBALS['nextbutton_font_color']; ?>"/>    (Click to select the font color of the result button.)</td>
            </tr>
            <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;"> Result Size of Next Button :- </th>
        <td><select name="resultbutton_font_size" id="resultbutton_font_size" class="resultbutton_font_size"/>
<?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['nextbutton_font_size'], $i );?>><?= $i; ?></option>
        
<?php } ?>
            </select>
        </td>
            </tr>
            
            <tr><td colspan="2"> <h1>Output Page Setting</h1><td></tr> 
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Background Color of Output Page :-</th>
        <td><input type="text" name="ansbackcoq" id="ansbackcoq" class="ansbackcoq" value="<?= $GLOBALS['ansbackcoq']; ?>"/></td>
            </tr>
            <tr class="sel_pp">
        <th  scope="row" style="width: 250px !important; padding-left: 0px !important;">Font Color of Output Page :-</th>
        <td><input type="text" name="ansbackcof" id="ansbackcof" class="ansbackcof" value="<?= $GLOBALS['ansbackcof']; ?>"/></td>
            </tr>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Output in Bold :- </th>
        <td><input type="checkbox" name="anscfoabold" id="anscfoabold" class="anscfoabold" value="bold"<?php checked($GLOBALS['anscfoabold'], "bold" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick for Output in Italics :- </th>
        <td><input type="checkbox" name="anscfoaitalic" id="anscfoaitalic" class="anscfoaitalic" value="italic"<?php checked($GLOBALS['anscfoaitalic'], "italic" );?>/></td>
            </tr>
             <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Tick to Underline :- </th>
        <td><input type="checkbox" name="anscfoaquline" id="anscfoaquline" class="anscfoaquline" value="underline"<?php checked($GLOBALS['anscfoaquline'], "underline" );?>/></td>
            </tr>
        <tr class="sel_pp">
        <th scope="row" style="width: 250px !important; padding-left: 0px !important;">Select Font Size :- </th>
        <td><select name="ansoafontsaz" id="ansoafontsaz" class="ansoafontsaz"/>
<?php
            for($i=8;$i<=36;$i++){
?>
        <option value="<?= $i; ?>"<?php selected($GLOBALS['ansoafontsaz'], $i );?>><?= $i; ?></option>        
<?php } ?>
            </select>
        </td>
            </tr>
       
    </table>
    <script src='<?php echo plugins_url('js/jquery.js',__FILE__); ?>'></script>
<script src='<?php echo plugins_url('js/spectrum.js',__FILE__); ?>'></script>
<link rel='stylesheet' href='<?php echo plugins_url('css/spectrum.css',__FILE__); ?>' />
<?php submit_button(); ?>
<?php        
        require_once 'settingjs.php';?>
</form></div>
<?php 
}   
        $GLOBALS['activate_quiz']=esc_attr( get_option('activate_quiz') );
        $GLOBALS['htitle']=  !empty(esc_attr( get_option('htitle') ))?esc_attr( get_option('htitle') ):"Participate in Quiz Contest";
        $GLOBALS['discription']=  !empty(esc_attr( get_option('discription') ))?esc_attr( get_option('discription') ):"Please Participate in this Quiz and win lots of Prises";
        $GLOBALS['mm']=esc_attr( get_option('mm') );
        $GLOBALS['ss']=esc_attr( get_option('ss') );
        $GLOBALS['enable']=  !empty(esc_attr( get_option('enable') ))?esc_attr( get_option('enable') ):"false";
        $GLOBALS['countdown']=  !empty(esc_attr( get_option('countdown') ))?esc_attr( get_option('countdown') ):"false";
        
        $GLOBALS['minimum_score']= esc_attr( get_option('minimum_score') );
        $GLOBALS['Price_button_text']=  !empty(esc_attr( get_option('Price_button_text') ))?esc_attr( get_option('Price_button_text') ):"You have won an attractive prize. Click here to claim it.";
        $GLOBALS['Button_color']=  !empty(esc_attr( get_option('Button_color') ))?esc_attr( get_option('Button_color') ):"green";
        $GLOBALS['Button_text_color']=  !empty(esc_attr( get_option('Button_text_color') ))?esc_attr( get_option('Button_text_color') ):"black";
        $GLOBALS['Price_url']=  esc_attr( get_option('Price_url') );
        
        $GLOBALS['backc']=  !empty(esc_attr( get_option('backc') ))?esc_attr( get_option('backc') ):"#DCDCDC";
        $GLOBALS['fontc']= !empty(esc_attr( get_option('fontc') ))?esc_attr( get_option('fontc') ):"#165678";
        $GLOBALS['Quizcfbold']=esc_attr( get_option('Quizcfbold') );
        $GLOBALS['Quizcfitalic']=esc_attr( get_option('Quizcfitalic') );
        $GLOBALS['Quizcfuline']=esc_attr( get_option('Quizcfuline') );
        $GLOBALS['Quizfontsaz']=esc_attr( get_option('Quizfontsaz') );
        $GLOBALS['hfontc']=!empty(esc_attr( get_option('hfontc') ))?esc_attr( get_option('hfontc') ):"#6B7B7B";
        $GLOBALS['cfbold']=esc_attr( get_option('cfbold') );
        $GLOBALS['cfitalic']=esc_attr( get_option('cfitalic') );
        $GLOBALS['cfuline']=esc_attr( get_option('cfuline') );
        $GLOBALS['fontsaz']=esc_attr( get_option('fontsaz') );
        $GLOBALS['backcoq']=!empty(esc_attr( get_option('backcoq') ))?esc_attr( get_option('backcoq') ):"#fff";
        $GLOBALS['backcooa']=!empty(esc_attr( get_option('backcooa') ))?esc_attr( get_option('backcooa') ):"beige";
        $GLOBALS['backcoqf']=!empty(esc_attr( get_option('backcoqf') ))?esc_attr( get_option('backcoqf') ):"#333";
        $GLOBALS['backcooaf']=!empty(esc_attr( get_option('backcooaf') ))?esc_attr( get_option('backcooaf') ):"#4b4b4b";
        $GLOBALS['cfqbold']=esc_attr( get_option('cfqbold') );
        $GLOBALS['cfqitalic']=esc_attr( get_option('cfqitalic') );
        $GLOBALS['cfquline']=esc_attr( get_option('cfquline') );
        $GLOBALS['qfontsaz']=esc_attr( get_option('qfontsaz') );
        $GLOBALS['cfoabold']=esc_attr( get_option('cfoabold') );
        $GLOBALS['cfoaitalic']=esc_attr( get_option('cfoaitalic') );
        $GLOBALS['cfoaquline']=esc_attr( get_option('cfoaquline') );
        $GLOBALS['oafontsaz']=esc_attr( get_option('oafontsaz') );
        $GLOBALS['ansbackcoq']=!empty(esc_attr( get_option('ansbackcoq') ))?esc_attr( get_option('ansbackcoq') ):"#546E7A";
        $GLOBALS['ansbackcof']=!empty(esc_attr( get_option('ansbackcof') ))?esc_attr( get_option('ansbackcof') ):"#fff";
        $GLOBALS['anscfoabold']=esc_attr( get_option('anscfoabold') );
        $GLOBALS['anscfoaitalic']=esc_attr( get_option('anscfoaitalic') );
        $GLOBALS['anscfoaquline']=esc_attr( get_option('anscfoaquline') );
        $GLOBALS['ansoafontsaz']=esc_attr( get_option('ansoafontsaz') );
        
        $GLOBALS['nextbutton_background_color']=!empty(esc_attr( get_option('nextbutton_background_color') ))?esc_attr( get_option('nextbutton_background_color') ):"#60961c";
        $GLOBALS['nextbutton_font_color']=!empty(esc_attr( get_option('nextbutton_font_color') ))?esc_attr( get_option('nextbutton_font_color') ):"#ffffff";
        $GLOBALS['nextbutton_font_size']=esc_attr( get_option('nextbutton_font_size') );
        $GLOBALS['resultbutton_background_color']=!empty(esc_attr( get_option('resultbutton_background_color') ))?esc_attr( get_option('resultbutton_background_color') ):"#60961c";
        $GLOBALS['resultbutton_font_color']=!empty(esc_attr( get_option('resultbutton_font_color') ))?esc_attr( get_option('resultbutton_font_color') ):"#ffffff";
        $GLOBALS['resultbutton_font_size']=esc_attr( get_option('resultbutton_font_size') );
?>