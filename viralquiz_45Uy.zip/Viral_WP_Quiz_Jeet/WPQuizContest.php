<?php
/*
Plugin Name: Viral WP Quiz Jeet
Plugin URI:http://teknikforce.com/
Description: Create full-featured quizzes right inside your Wordpress blog and engage your visitors better. Displays quiz results and you can also unlock prizes and access to specific pages. Supports social sharing to get you viral traffic.
Author: TEKNIKFORCE
Version: 1.0.0
Author URI: http://teknikforce.com/
*/

require_once 'setting_page.php';
define( 'QUIZ_TABLE', 'Quiz' );
define('QUESTION_TABLE', 'Question');
define('RESULT_TABLE', 'Result');
register_activation_hook( __FILE__, 'install_quiz_table' );
function install_quiz_table() {

	global $wpdb;
  
         $charset_collate = '';
    if (!empty($wpdb->charset)) {
        $charset_collate = "DEFAULT CHARACTER SET {$wpdb->charset}";
    }
    if (!empty($wpdb->collate)) {
        $charset_collate .= " COLLATE {$wpdb->collate}";
    }
         $table_name = $wpdb->prefix . QUIZ_TABLE;
	 $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (" .
				"`id` bigint(11) NOT NULL AUTO_INCREMENT,".				
                                "`quiz_title` longtext NOT NULL,".
                                "`quiz_image_name` varchar(255) NOT NULL,".
				"PRIMARY KEY (`id`)".
			 ") {$charset_collate} ENGINE=InnoDB;";
         $wpdb->query($sql);     
    
	 $table_name = $wpdb->prefix . QUESTION_TABLE;
	 $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (" .
				"`id` bigint(11) NOT NULL AUTO_INCREMENT,".
				"`question_number` varchar(255) NOT NULL,".
				"`quiz_name` longtext NOT NULL,".
				"`question` longtext NOT NULL,".
                                "`question_description` longtext NOT NULL,".
				"`option1` longtext NOT NULL,".
                                "`option2` longtext NOT NULL,".
                                "`option3` longtext NOT NULL,".
                                "`option4` longtext NOT NULL,".
                                "`option5` longtext NOT NULL,".
                                "`option6` longtext NOT NULL,".
                                "`correct_answer` longtext NOT NULL,".
                                "`question_image_name` varchar(255) NOT NULL,".
				"PRIMARY KEY (`id`)".
			 ") {$charset_collate} ENGINE=InnoDB;";
         $wpdb->query($sql);
    
         $table_name = $wpdb->prefix . RESULT_TABLE;
	 $sql = "CREATE TABLE IF NOT EXISTS {$table_name} (" .
				"`id` bigint(11) NOT NULL AUTO_INCREMENT,".
                                "`result_quiz_name` longtext NOT NULL,".
				"`score` varchar(255) NOT NULL,".
                                "`score_statement` longtext NOT NULL,".
				"`score_image_name` varchar(255) NOT NULL,".
				"PRIMARY KEY (`id`)".
			 ") {$charset_collate} ENGINE=InnoDB;";
         $wpdb->query($sql);
	}
register_deactivation_hook( __FILE__, 'Uninstall_quiz_table' );	
function Uninstall_quiz_table(){
    global $wpdb;
    $sql = "DROP TABLE IF EXISTS " . $wpdb->prefix . QUIZ_TABLE . ", " .
            $wpdb->prefix . QUESTION_TABLE .", " .
            $wpdb->prefix . RESULT_TABLE .
            ";";
    $wpdb->query($sql);
}
add_action('wp_enqueue_scripts', 'WPQuizContest_Script');
function WPQuizContest_Script(){
    
    global $post;
    
    if(has_shortcode($post->post_content, "Show_Quiz_Contest")){
     wp_enqueue_script( 'btstoltipjsw', plugins_url('js/jquery-2.2.4.js', __FILE__) );
     wp_enqueue_script( 'ques_lib_js', plugins_url('js/jquery.js', __FILE__) );
     wp_enqueue_script( 'ques_butsrp_js', plugins_url('js/bootstrap.min.js', __FILE__) );
    
    
     
     
    }
}
add_action('wp_enqueue_scripts', 'WPQuizContest_Style');
function WPQuizContest_Style(){
    
    global $post;
    
    if(has_shortcode($post->post_content, "Show_Quiz_Contest")){
    wp_enqueue_style('ques_butsrp_css', plugins_url('css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('main_css', plugins_url('css/main_css.css', __FILE__));
    
    }
}

add_shortcode("Show_Quiz_Contest", "Show_Quiz_Contest");

add_action('wp_enqueue_scripts', 'WPQuizContest_Run_Script');
function WPQuizContest_Run_Script(){
    
    global $post;
    
    if(has_shortcode($post->post_content, "Run_Quiz_contest")){
     wp_enqueue_script( 'btstoltipjsww', plugins_url('js/jquery-2.2.4.js', __FILE__) );
     wp_enqueue_script( 'run_lib_js', plugins_url('js/jquery.js', __FILE__) );
     wp_enqueue_script( 'run_butsrp_js', plugins_url('js/bootstrap.min.js', __FILE__) );
 
    }
}

add_action('wp_enqueue_scripts', 'WPQuizContest_Run_Style');
function WPQuizContest_Run_Style(){
    
    global $post;
    
    if(has_shortcode($post->post_content, "Run_Quiz_contest")){   
    wp_enqueue_style('run_butsrp_css', plugins_url('css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('run_quiz', plugins_url('css/run_quiz.css', __FILE__));  
    
    }
}

add_action('wp_enqueue_scripts', 'WPQuizContest_Summary_Script');
function WPQuizContest_Summary_Script(){
    
    global $post;
    
    if(has_shortcode($post->post_content, "Summary_Quiz_contest")){
        wp_enqueue_script( 'Summary', plugins_url('js/jquery-2.2.4.js', __FILE__) );
    
        wp_enqueue_script( 'Summary_lib_js', plugins_url('js/jquery.js', __FILE__) );
        wp_enqueue_script( 'Summary_butsrp_js', plugins_url('js/bootstrap.min.js', __FILE__) );     
    
    }
}
add_action('wp_enqueue_scripts', 'WPQuizContest_Summary_Style');
function WPQuizContest_Summary_Style(){
    
    global $post;   
    if(has_shortcode($post->post_content, "Summary_Quiz_contest")){  
    wp_enqueue_style('Summary_butsrp_css', plugins_url('css/bootstrap.min.css', __FILE__));
    wp_enqueue_style('Summary_style_css', plugins_url('css/summary_quiz.css', __FILE__));   
    
    }
}
function Show_Quiz_Contest(){
    global $wpdb;
  $table_name = $wpdb->prefix."posts"; 
  $sql_quiz = $wpdb->prepare( "select post_title from $table_name where post_content = %s and post_type = %s","[Show_Quiz_Contest/]","page");
  $first_page=$wpdb->get_col($sql_quiz);
 
  $sec_quiz = $wpdb->prepare( "select post_title from $table_name where post_content = %s and post_type = %s","[Run_Quiz_contest/]","page");
  $second_page=$wpdb->get_col($sec_quiz);
  
//  $table_name = $wpdb->prefix."Quiz"; 
//  $quiz = $wpdb->prepare( "select * from $table_name where quiz_title = %s","$GLOBALS[activate_quiz]");
//  $quiz_details=$wpdb->get_results($quiz);  //print_r($quiz_details); 
  $art=  array();
//$quzarrimg=  array();
  for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
      $table_name = $wpdb->prefix."Quiz"; 
  $quiz11 = $wpdb->prepare( "select * from $table_name where quiz_title = %s","$GLOBALS[$k]");
  $quiz_details11=$wpdb->get_results($quiz11);
  
  for($j=0;$j<=count($quiz_details11)-1;$j++){
      array_push($art,count($quiz_details11[$j]));//count($quiz_details11[$j]);
      
    //print_r($quiz_details11[$j]);
  }
  }
   $numKeys = count($art);
     // print_r($art);
?>   
<div class='container-fluid headng'>
     <span class='heding' style='color:<?= $GLOBALS['hfontc']; ?> !important;  font-style: <?= $GLOBALS['cfitalic']; ?> !important; font-weight:<?= $GLOBALS['cfbold']; ?> !important; text-decoration:<?= $GLOBALS['cfuline']; ?> !important; font-size: <?= $GLOBALS['fontsaz']; ?>px !important;'><?= $GLOBALS['htitle']; ?>:</span> 
         <div class='main_box' style='background-color:<?= $GLOBALS['backc']; ?> !important;'>
           <div class='nextpage' style='background-color:<?= $GLOBALS['backc']; ?> !important;'>
                       
    <div class='hdg text-center' > 

        <p style="padding-top: 15px;"><?= $GLOBALS['discription']; ?></p>

<a href="#" id="tooltip_quiz" data-toggle="tooltip" data-placement="top" title="">      
<?php
    if($numKeys>0){
        for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
     // echo $GLOBALS[$k]."$k";
  $table_name = $wpdb->prefix."Quiz"; 
  $quiz11 = $wpdb->prepare( "select * from $table_name where quiz_title = %s","$GLOBALS[$k]");
  $quiz_details11=$wpdb->get_results($quiz11);
  $json = json_encode($quiz_details11);
  $jsondecode = json_decode($json, true);
  foreach($jsondecode as $key => $val){//echo "<pre>";print_r($val); echo "</pre>";
?>
    <div class="feature-img" style="padding-bottom: 10px;color: <?= $GLOBALS['fontc']; ?> !important;   font-style:<?= $GLOBALS['Quizcfitalic']; ?>  !important; font-weight:<?= $GLOBALS['Quizcfbold']; ?> !important; text-decoration: <?= $GLOBALS['Quizcfuline']; ?> !important; font-size: <?= $GLOBALS['Quizfontsaz']; ?>px !important;">        
    <?= $val['quiz_title']; ?>  
    </div>
                   
<?php 
                          $runurl = get_permalink(get_page_by_title("$second_page[0]"));
                                                  
		          $quiz_contesturl = get_permalink(get_page_by_title("$first_page[0]"));
                                                
                            $image = wp_get_attachment_image_src(get_post_thumbnail_id(), 'medium');
                            ?> <div class="imgcss" style="width:100%;">
                                
                                <img class="quiz_img" src="<?= $val['quiz_image_name']; ?>" alt="<?= $val['quiz_title']; ?>"/></div>
                                 
                                    <?php    
								$quiz_contes= get_the_title();
							echo "
		        <form id='form_search' method='post' action=".$runurl." style='display:none'>  
		        ​<textarea id='qtitle' name='qtitle' rows='5' cols='70' style='display:none' >$quiz_contes</textarea>
				​<textarea id='qpage' name='qpage' rows='5' cols='70' style='display:none' >$quiz_contesturl</textarea>
                </form>";?>                  
                   
   <?php 
              }
  }  
  
    }
 else {       
     echo "No Quiz Contest found.Please Insert your Quiz";     
    } 
    //}
 //else {
     //  echo "No Quiz Contest found"; 
   // }
?>    
</a>
         
    </div></div></div></div>  

   
<script language="JavaScript" type="text/javascript">
$(document).ready(function () {
$(".nextpage a").bind("click",function(){
    $(this).find('form').submit();
    
        return false;
 });
});	

</script>	
<?php
}
add_shortcode("Run_Quiz_contest", "Run_Quiz_contest");

//require_once 'AddmetaBox.php';

function Run_Quiz_contest(){
global $wpdb;
  $table_name = $wpdb->prefix."posts"; 
  $sql_quiz = $wpdb->prepare( "select post_title from $table_name where post_status = %s and post_type = %s","publish","outcomes");
  $res_quiz=$wpdb->get_col($sql_quiz);
   
  $sql_show = $wpdb->prepare( "select post_title from $table_name where post_content = %s and post_type = %s","[Show_Quiz_Contest/]","page");
  $onpage=$wpdb->get_col($sql_show);

  $sec_main = $wpdb->prepare( "select post_title from $table_name where post_content = %s and post_type = %s","[Run_Quiz_contest/]","page");
  $twicw_page=$wpdb->get_col($sec_main);

  $sec_summary = $wpdb->prepare( "select post_title from $table_name where post_content = %s and post_type = %s","[Summary_Quiz_contest/]","page");
  $thrice_page=$wpdb->get_col($sec_summary);
  
  $art=  array();
  //$quzarrimg=  array();
  for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
      $table_name = $wpdb->prefix."Quiz"; 
  $quiz11 = $wpdb->prepare( "select * from $table_name where quiz_title = %s","$GLOBALS[$k]");
  $quiz_details11=$wpdb->get_results($quiz11);
  
  for($j=0;$j<=count($quiz_details11)-1;$j++){
      array_push($art,count($quiz_details11[$j]));//count($quiz_details11[$j]);
      
   // print_r($quiz_details11[$j]);
  }
  }
   $numKeys = count($art);  
   
 
  //$table_name = $wpdb->prefix."Question"; 
  //$quiz_question = $wpdb->prepare( "select * from $table_name where quiz_name = %s","$GLOBALS[activate_quiz]");
 // $questions=$wpdb->get_results($quiz_question);
 

  @$qpage = $_POST['qpage'];
  @$qtitle = $_POST['qtitle'];

    require_once 'quizcontt.php';  
?>

     <div class="container-fluid fnt_main"> <div id="ind"><?php echo get_permalink(get_page_by_title('Run')); ?></div>

	 <div id="qurl" ><?php echo $qpage; ?></div>

	 <div id="qtitle" ><?php echo $qtitle; ?></div>
         <div id="run" style="display:none;" ><?php echo get_permalink(get_page_by_title("Play")); ?></div>
         <div id="countdowntimer"><span id="ms_timer"></span><span type='text' name='timer' class='timer' id='timer'/></span></div>
<?php
	if( $numKeys>0 ) {
       $n=0;
 for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
     $table_name = $wpdb->prefix."Question"; 
  $quiz_question11 = $wpdb->prepare( "select * from $table_name where quiz_name = %s","$GLOBALS[$k]");
  $questions11=$wpdb->get_results($quiz_question11);
  $json = json_encode($questions11);
  $jsondecode = json_decode($json, true);
  foreach($jsondecode as $key => $val){
             
      //echo "<pre>";print_r($val); echo "</pre>";             
      //echo "<pre>";echo $val['quiz_name']; echo "</pre>";      
 
	  //for($n=0; $n<=count($questions)-1; $n++ ) {
?>       
         <div class='all_disp Q<?= $n; ?>' style='background-color:<?= $GLOBALS['backcoq']; ?> !important; display:none;'>

            <div class='qno  qnoco<?php echo $n+1; ?>'><h3><?php echo $n+1; ?></h3><div class="correct_show<?php echo $n+1; ?>"></div></div>
            <div><div class='dispq'style='margin-left: 30px !important;margin-top: 26px !important;color:<?= $GLOBALS['backcoqf']; ?> !important;   font-style:<?= $GLOBALS['cfqitalic']; ?>  !important; font-weight:<?= $GLOBALS['cfqbold']; ?> !important; text-decoration: <?= $GLOBALS['cfquline']; ?> !important; font-size: <?= $GLOBALS['qfontsaz'];  ?>px !important;' >
                    <h2><?php echo $val['question']; ?></h2></div>	
                <p class="message" id="message"> <?= $val['question_description']; ?> </p>
                
         <center><img id="question_img" class="question_img" src="<?php echo $val['question_image_name']; ?>"></center>
<?php
echo'<div class="ans">';
$g = $n+1;
//echo strlen($val['option1']);
if ( strlen($val['option1'])>0 ) {
?>
 	<label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value='<?= $val["option1"]; ?>'>&nbsp;&nbsp;<?php echo $val['option1']; ?></p></label>
<?php
}
if( strlen($val['option2'])>0 ){
?>
        <label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value="'<?= $val["option2"]; ?>'">&nbsp;&nbsp;<?php echo $val['option2']; ?></p></label>
<?php
}
if( strlen($val['option3'])>0 ){
?>       
        <label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value='<?= $val["option3"]; ?>'>&nbsp;&nbsp;<?php echo $val['option3']; ?></p></label>
<?php
}
if( strlen($val['option4'])>0 ){
?>      
        <label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value='<?= $val["option4"]; ?>'>&nbsp;&nbsp;<?php echo $val['option4']; ?></p></label>
<?php
}
if( strlen($val['option5'])>0 ){
?>        
        <label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value='<?= $val["option5"]; ?>'>&nbsp;&nbsp;<?php echo $val['option5']; ?></p></label>
<?php
}
if( strlen($val['option6'])>0 ){
?>       
        <label><p class='opt_all' style='background-color:<?= $GLOBALS["backcooa"]; ?> !important; color:<?= $GLOBALS["backcooaf"]; ?> !important;font-style:<?= $GLOBALS["cfoaitalic"]; ?> !important; font-weight:<?= $GLOBALS["cfoabold"]; ?> !important; text-decoration:<?= $GLOBALS["cfoaquline"]; ?> !important; font-size:<?= $GLOBALS["oafontsaz"]; ?> !important;'><input type="radio" onclick="optionselected(this,'<?= $val["option1"]; ?>','<?= $val["correct_answer"]; ?>','<?= $g; ?>')" class='opt2<?= $g; ?>' name='opt<?= $g; ?>' id='opt1<?= $g; ?>' value='<?= $val["option6"]; ?>'>&nbsp;&nbsp;<?php echo $val['option6']; ?></p></label>
<?php
}
?>
<div class="answer " id="answer" name="answer" style="display:none;"><?php echo $val['correct_answer']; ?></div>
            <div class="feedback" id="feedback"></div>
            </div></div>
         <span id="msg<?php echo $g; ?>"></span>
     </div>
<?php   
//}
 $n++;  
 }
  } 
?>
     <div class="total_question" style="display:none"><?php echo $n; ?></div>
      <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
      <div class="btn-div">
          <a class="btn btn-success next" id="next" style="background-color:<?= $GLOBALS['nextbutton_background_color']; ?> !important; color:<?= $GLOBALS['nextbutton_font_color']; ?> !important; font-size:<?= $GLOBALS['nextbutton_font_size']; ?>px !important; box-shadow: none;" >NEXT</a>
       <a href='#' style="display: none; background-color: <?= $GLOBALS['resultbutton_background_color']; ?> !important; color:<?= $GLOBALS['resultbutton_font_color']; ?> !important; font-size:<?= $GLOBALS['resultbutton_font_size']; ?>px !important; box-shadow: none;text-decoration: none !important;border: none !important;" class="btn btn-success summary" id="resultpop">SHOW RESULT
<?php
               $quiz_contturl = get_permalink(get_page_by_title("$onpage[0]"));
               $summaryurl = get_permalink(get_page_by_title("$thrice_page[0]"));
               $questionurl = get_permalink(get_page_by_title("$twicw_page[0]"));
?>  
           </a></div>
<?php
$ct=0;
for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
     $table_name = $wpdb->prefix."Question"; 
  $quiz_question11 = $wpdb->prepare( "select * from $table_name where quiz_name = %s","$GLOBALS[$k]");
  $questions11=$wpdb->get_results($quiz_question11);//echo '<pre>';print_r($questions11);echo '</pre>';
  $json = json_encode($questions11);
  $jsondecode = json_decode($json, true);
   $ct= $ct + count($jsondecode);
  }//echo $ct;
?>      
<script type="text/javascript" src="<?= plugins_url("js/jquery.cookie.js",__FILE__); ?>"></script>
<script language="JavaScript" type="text/javascript">
$(document).ready(function () {
$(".btn-div .summary").bind("click",function(){
    var got;
    var totalattempt = '';
    var rightcollection = "";
    var incorectcollection = "";
    //var qno = $(".all_disp").find(".qno").text();
    var lastquestion = "<?= $ct; ?>";
    var timr =  $("#timer").text();
   
      totalattempt = atemp.length
      rightcollection = correct.length;
      incorectcollection = wron.length;
      got=rightcollection+" of "+lastquestion; //alert(rightcollection+" of "+lastquestion);
     var minimum_score="<?= $GLOBALS['minimum_score']; ?>";
    
      var url = "<?php echo "$summaryurl"; ?>?"+("<?= base64_encode($summaryurl); ?>")+"/"+("<?= base64_encode($quiz_contturl); ?>")+"/"+window.btoa(lastquestion)+"/"+window.btoa(totalattempt)+"/"+window.btoa(rightcollection)+"/"+window.btoa(incorectcollection)+"/"+window.btoa(got)+"/"+window.btoa(timr)+"/"+window.btoa(minimum_score);
      window.location.href = url;
      return false;
 });
});	

</script>
<?php 
        }
wp_reset_postdata();
    
}
add_shortcode("Summary_Quiz_contest", "Summary_Quiz_contest");

function Summary_Quiz_contest(){
@$quer_url = $_SERVER['QUERY_STRING'];
  $array = explode("/", $quer_url);
@$timr = base64_decode($array[7]);
@$Total_Attempt = base64_decode($array[3]);
@$Total_Question = base64_decode($array[2]);
@$Right_Collection = base64_decode($array[4]);
@$Incorect_Collection = base64_decode($array[5]);
@$got = base64_decode($array[6]);
@$minimum_score = base64_decode($array[8]);
@$summary_url = base64_decode($array[0]);
@$new_quiz = base64_decode($array[1]);
?>
<style>  
    .share_center .fb-share-button span iframe{
    width: 76px !important;
    height: 100% !important;
    transform: scale(1.5);
-ms-transform: scale(1.5); 
-webkit-transform: scale(1.5); 
-o-transform: scale(1.5); 
-moz-transform: scale(1.5); 
    }
</style>
<span style="display:none;"><?php  $perlink = the_permalink(); ?></span>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link rel="stylesheet" href="<?= plugins_url("css/summary_quiz.css",__FILE__); ?>">
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="<?= plugins_url("js/jquery.cookie.js",__FILE__); ?>"></script>

<script type="text/javascript" src="<?= plugins_url("screenshot/html2canvas.js",__FILE__); ?>"></script>
<script type="text/javascript">
        $(function () {
            if ("<?= $timr; ?>" != null && <?= $Total_Attempt; ?> != null && <?= $Total_Question; ?> != null && <?= $Right_Collection ; ?> != null && <?=  @$Incorect_Collection; ?> != null) {
                var data = "";
                data += "<div class='timetaken  feed'>You took "+ "<?= $timr; ?>" + " seconds to complete this quiz</div><div class='totalque  feed'>Total Number of Questions :-  " + <?= $Total_Question; ?> + "</div><div class='totalatmp  feed'>Total Number of Attempts :- " + <?= $Total_Attempt; ?> + "</div><div class='rightt  feed'>Correct Answers :- " + <?= $Right_Collection; ?> + "</div><div class='wrongg  feed'>Incorrect Answers :- " + <?= $Incorect_Collection; ?>+"</div>";
                $("#Data").html(data);                 
            }
        });
    </script>
    <div class="container-fluid" id="screenshort" style="width: 600px !important;height: auto !important;transform: none;">
        <div class="Data" id="screen" style="text-align: center; background-color:<?= $GLOBALS['ansbackcoq']; ?> !important;color:<?= $GLOBALS['ansbackcof']; ?> !important;   font-style:<?= $GLOBALS['anscfoaitalic']; ?>  !important; font-weight:<?= $GLOBALS['anscfoabold']; ?> !important; text-decoration: <?= $GLOBALS['anscfoaquline']; ?> !important; font-size: <?= $GLOBALS['ansoafontsaz']; ?>px !important;"><span id="Data"></span>
<?php
if($got != NULL){
    global $wpdb;
    $table_name = $wpdb->prefix."Result"; 
    $quiz_result = $wpdb->prepare( "select * from $table_name where score = %s","$got");
    $results=$wpdb->get_results($quiz_result);
    @$pro = get_page_by_title($got, OBJECT,'Outcomes' );
for($j=0;$j<=count($results)-1;$j++){?>
            <center><div class="feed">'<?= $results[$j]->score_statement; ?>'</div><img style="max-height: 230px;"   src="<?= $results[$j]->score_image_name; ?>" alt=""></center>
<?php
}
}
?>
        <div class="share_center" id="share_center">
<a class="btn btn-success resultpop newquiz" id="newquiz">New Quiz</a><br>
<?php
if($GLOBALS['minimum_score']<=$Right_Collection){
 echo '<a href="'.$GLOBALS['Price_url'].'" class="" id="newquiz"><span style="width: 100% !important; word-wrap: break-word !important;margin-top: 3%; background-color:'.$GLOBALS['Button_color'].' !important;color:'. $GLOBALS['Button_text_color'].' !important;display: inline-block !important;border-radius: 5px !important;">'.$GLOBALS['Price_button_text'].'</span></a>';
}
?>
</div>
<script>
$(window).load(function(){
              html2canvas($('#screenshort'), {  
                  useCORS: true,
			onrendered: function(canvas)  
			{                        
				var img = canvas.toDataURL('image/png',"image/octet-stream");
				$.post("<?= $perlink; ?>", {data: img}, function (file) {//alert(file);
				//window.location.href = img;
                            });   
			}
		});
              if("<?= $summary_url; ?>" !=null && "<?= $quer_url; ?>" != null){
          $(".share_center").find(".newquiz").click(function(){            
             window.location.href = "<?= $new_quiz; ?>";          
          }); 
          }
             });
             $(document).ready(function(){
             
             });
        </script>
        <div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6&appId=106412199783493";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php
@$data = $_POST['data'];
 $directory = __DIR__.'/images/';
  $files = glob($directory . '*.png');
  //echo $files != false;//print_r($files);
if ( $files != false )
{   // print_r($files);
    $filecount = count( $files );
    //echo $filecount;


	 $file = "screenshort".$filecount. '.png';
	 //echo $file;
	
	 $uri =  substr($data,strpos($data,",")+1); //echo $uri != NULL;
	 if($uri != NULL){

	 file_put_contents(__DIR__.'/images/'.$file, base64_decode($uri));
       
         } 
         ?>
        <div class="share_center" id="share_center"><div  class="fb-share-button" data-href="<?= plugins_url("images/",__FILE__).$file; ?>?u=http://shopperideas.com/?page_id=65" data-layout="button" data-size="large" data-mobile-iframe="false"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?quite=http://shopperideas.com/?page_id=65"></a></div>
	<a href="https://twitter.com/share?url=<?= plugins_url("images/",__FILE__).$file; ?>" class="twitercls btn btn-social btn-twitter" id="resultpop"  onclick="window.open(this.href, 'twittershare','left=20,top=20,width=500,height=325,toolbar=1,resizable=0'); return false;"><span class="fa fa-twitter"></span> Share</a></div></div></div>       
<?php     
	 //exit;
         }
}  

function wpquizjeettnf_footer_admin () {
    
     @$screen = get_current_screen();
         // print_r($screen);
    if(($screen->parent_file == 'Quiz_Contest_page')){
?>
<style>
.logocont{ margin-bottom: -28px;}
.logocont .tnfcreated{
   font-size:15px;
  
}
.logocont a{text-decoration: none;font-size:15px; color: #1b1b1b;}
.logocont a:hover{text-decoration: none !important;}
.logocont a:hover{color: #0073aa;}
</style>

     <div class="container-fluid logocont">
           <div class="tnfcreated" > Created by : </div>
                <a href="http://teknikforce.com/"><img class="tekink" src="<?= plugins_url("images/logo.png",__FILE__); ?>" title="Teknikforce" alt="Teknikforce" style="cursor: pointer;outline:none;width: 160px;margin-bottom: -4px;" onclick="window.external.teknikforce();">
                    : http://teknikforce.com 
                </a>
    </div>  
    <?php
    }
}
add_filter('admin_footer_text', 'wpquizjeettnf_footer_admin');