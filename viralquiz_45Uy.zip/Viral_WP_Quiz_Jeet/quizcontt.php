<?php
$ct=0;
for($k=0;$k<=$GLOBALS['quesno']-1;$k++){
     $table_name = $wpdb->prefix."Question"; 
  $quiz_question11 = $wpdb->prepare( "select * from $table_name where quiz_name = %s","$GLOBALS[$k]");
  $questions11=$wpdb->get_results($quiz_question11);//echo '<pre>';print_r($questions11);echo '</pre>';
  $json = json_encode($questions11);
  $jsondecode = json_decode($json, true);
   $ct= $ct + count($jsondecode);
  }//echo $ct;
?>
<script type="text/javascript" src="<?= plugins_url('js/jquery-2.0.3.js', __FILE__); ?>"></script>
<script type="text/javascript" src="<?= plugins_url('js/jquery.countdownTimer.js', __FILE__); ?>"></script>
<link rel="stylesheet" type="text/css" href="<?= plugins_url('css/jquery.countdownTimer.css', __FILE__); ?>" />
<script src="<?= plugins_url('js/timer.jquery.js', __FILE__); ?>"></script>
<script language="JavaScript" type="text/javascript"> 
    var atemp = [];
    var correct = [];
    var wron = [];
    $(document).ready(function(){
        var qno = $(".all_disp").find(".qno").text();qno.slice("");
        var lastq = "<?= $ct; ?>";
      
        var count = 0;
        var count_qus = 0;
        $(".Q0").css("display","block");
      if(lastq > "1"){
       count_qus++
     
        $(".btn-div .next").click(function(){
         
             count++;
              if("true" == "<?php echo $GLOBALS['enable']; ?>"){
         for(var i=0;i<=count-1;i++){  
         $(".Q"+i).css("display","none");
     }
      
         $(".Q"+count).css("display","block");
        // (parseInt(lastq, 10) - parseInt(1, 10))
     
       if((lastq-"1") == (count)){
        $(".btn-div .next").css("display","none");
        $(".summary").css("display","inline-block");
      }

       }
         if("false" == "<?php echo $GLOBALS['enable']; ?>"){
        if($('input[name="opt'+count+'"]:checked', '.ans').prop("checked") == true){
            window.parent.scrollTo(0,310);
         for(var i=0;i<=count-1;i++){     
         $(".Q"+i).css("display","none");
     }
     
         $(".Q"+count).css("display","block");
         (parseInt(lastq, 10) - parseInt(1, 10))
     //alert(lastq-"1");alert(count);
       if((lastq-"1") == (count)){
        $(".btn-div .next").css("display","none");
        $(".summary").css("display","inline-block");
      }

       }
       else{
            $("#msg"+count).text("");
           $("#msg"+count).append("First answer the current question then click next.").css({"color":"#d83b01","font-weight":"700","font-size":"20px"});
          
           count--;
       }
   }
        });
        }
        else{
         $(".btn-div .next").css("display","none");
        $(".summary").css("display","inline-block");
        }
   
    });
        
    function optionselected(data,utr,ret,qn){
          // alert(qn);
          $("#msg"+qn).text("");
           var lr = $(data).attr('id');
           
           var slectans = $("#"+lr).parents(".ans").find('input[name="opt'+qn+'"]:checked', '.ans').val();
           var rtans = $('#'+lr).parents('.ans').find('.answer').text();
          
            $('#'+lr).parents('.ans').find('.feedback').text("");
            $('input[name="opt'+qn+'"]', '.ans').attr('disabled', true);
            if(slectans !=null && slectans !="")
            atemp.push(slectans);//alert(slectans == rtans);
           if(slectans == rtans) {
              $('#'+lr).parents('.ans').find('.feedback').append("Correct Answer").css({"color":"green","font-weight":"700","font-size":"20px"});
            
              if(slectans !=null && slectans !="")
              correct.push(slectans);
           }
           else{
                $('#'+lr).parents('.ans').find('.feedback').append("Incorrect Answer").css({"color":"red","font-weight":"700","font-size":"20px"});
                if(slectans !=null && slectans !="")
             wron.push(slectans);
           }
           
          
      } 
   if(true == <?= $GLOBALS['countdown']; ?>){
    $(document).ready(function(){
        $("#timer").css("display","none");
	$("#ms_timer").countdowntimer({
		minutes : <?= $GLOBALS['mm']; ?>,
                seconds : <?= $GLOBALS['ss']; ?>,
                size : "lg",
                timeUp : timeout
	});
        
});
function timeout(){
      $(".btn-div .next").css("display","none");
    $(".btn-div .next").css("display","none");
        $(".summary").css("display","inline-block");
  
    
     $("input[type=radio]").attr('disabled', true);
    window.parent.scrollTo(0,0);
        
    }
    }
    else if(false == <?= $GLOBALS['countdown']; ?>){
         $(document).ready(function(){
			var hasTimer = false;
			// Init timer start
			        hasTimer = true;
				$('.timer').timer({
					format: '%M:%S'
                                });
				$(this).addClass('hidden');
				$('.pause-timer-btn, .remove-timer-btn').removeClass('hidden');
                                
                                // Init timer pause
			$('.summary').on('click', function() {
				$('.timer').timer('pause');
				$(this).addClass('hidden');
				$('.resume-timer-btn').removeClass('hidden');
                               var timr =  $("#timer").text();
                              
                                $(".timetaken").append("<p class='timetaken'>You took "+timr+" minutes to complete this quiz</p>");
			});
                        
                        // Remove timer
			$('.newquiz').on('click', function() {
				hasTimer = false;
				$('.timer').timer('remove');
				$(this).addClass('hidden');
				$('.start-timer-btn').removeClass('hidden');
				$('.pause-timer-btn, .resume-timer-btn').addClass('hidden');
			});

			});
                    }
</script>