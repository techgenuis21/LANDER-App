<?php
global $wpdb;
$table_name = $wpdb->prefix."Question";
$Question_result = $wpdb->get_results ("SELECT * FROM $table_name");
?> 
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
 <link href="<?= plugins_url('css/bootstrap.min.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
 <script>
  function deletequestion(n,event){
         var del = confirm("Press ok and delete this question.");
                   if (del == true){ 
                 var quesdelet =$(".quwstion_action_heading").find("#questiondelete"+n).attr("title");//alert(quesdelet);
                 quesdelet = encodeURIComponent(quesdelet);
                
                 $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/Question_delete.php' , __FILE__ );?>',
   		data: "quesdelet1="+quesdelet,
                success: function(msg){
                  alert(msg);
                  window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_Questions");
                }
               });  
               }
               event.preventDefault();
              }
 </script>
<table class="table table-striped table-hover all_table_">
  <thead>
    <tr>
        <th class="question_no_theading">Question Number</th>
         <th class="question_no_theading">Quiz Name</th>
      <th class="question_theading">Questions</th>
      <th class="question_Action_theading">Action to be Taken</th>
      
    </tr>
  </thead>
  <tbody>
      <?php   for($i=0;$i<=count($Question_result)-1;$i++){?>
    <tr>
      <td class="quwstion_no_heading"><?= $Question_result[$i]->question_number; ?></td>
      <td class="quwstion_quiz_heading"><?= $Question_result[$i]->quiz_name; ?></td>
      <td class="quwstion_heading"><?= $Question_result[$i]->question; ?></td>
      <td class="quwstion_action_heading">
          <a href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_Questions" id="questiondelete<?= $i; ?>" onclick="deletequestion('<?= $i ?>')" class="btn btn-danger btn-xs questiondelete" name="questiondelete" title="<?= $Question_result[$i]->question; ?>"><span class="glyphicon glyphicon-trash"></span> DELETE</a>
          <a id="questionedit<?= $i; ?>" onclick="editquestion('<?= $i ?>','<?= $Question_result[$i]->question; ?>','<?= $Question_result[$i]->question_number; ?>')" class="btn btn-success btn-lg editbtn" name="questionedit" title="<?= $Question_result[$i]->question; ?>"><span class="glyphicon glyphicon-edit"></span> EDIT</a>
      </td>
    </tr>
    <?php 
    } 
    ?> 
  </tbody>
</table> 