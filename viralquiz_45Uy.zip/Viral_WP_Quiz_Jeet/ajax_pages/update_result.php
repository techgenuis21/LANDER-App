<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     //$hidden_result_quiz_name2 = utf8_decode($_GET['hidden_result_quiz_name1']);
     $hidden_result_score2 = utf8_decode($_GET['hidden_result_score1']);
     $hidden_result_score_statement2 = utf8_decode($_GET['hidden_result_score_statement1']); 
     $enter_score2 = utf8_decode($_GET['enter_score1']); 
     //$quiz_name2 = utf8_decode($_GET['quiz_name1']);
     $Scores_Statement2 = utf8_decode($_GET['Scores_Statement1']);
     $img_url2 = utf8_decode($_GET['img_url1']);
     
     $table_name1 = $wpdb->prefix."Result";
     $query = $wpdb->query("UPDATE {$table_name1} SET score = '{$enter_score2}', score_statement = '{$Scores_Statement2}', score_image_name = '{$img_url2}' WHERE score = '{$hidden_result_score2}' and score_statement = '{$hidden_result_score_statement2}'");
if ($query) {
echo "Result updation sucessfully done.";
}