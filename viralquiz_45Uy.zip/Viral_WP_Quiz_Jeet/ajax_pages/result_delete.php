<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
 
      $resudelet2 = utf8_decode($_GET['resudelet1']); 
      
     $table_name = $wpdb->prefix."Result";
		$wpdb->delete( $table_name, array( 'score' => $resudelet2 ), array( '%s' ) );
       echo "$resudelet2 has been Deleted";