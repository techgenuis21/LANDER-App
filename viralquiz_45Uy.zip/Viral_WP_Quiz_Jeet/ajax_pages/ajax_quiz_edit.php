<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $quiz2 = utf8_decode($_GET['quiz1']); 
     $table_name = $wpdb->prefix."Quiz";
     $quiz_result = $wpdb->get_results ("SELECT * FROM $table_name where quiz_title = '$quiz2'");
     echo $json = json_encode($quiz_result);
     // $jsondecode = json_decode($json, true);
     //print_r($jsondecode[0]);