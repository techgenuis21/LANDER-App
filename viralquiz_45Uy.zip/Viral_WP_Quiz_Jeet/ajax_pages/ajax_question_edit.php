<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $question2 = utf8_decode($_GET['question1']); 
     $question_number2 = utf8_decode($_GET['question_number1']);
     $table_name = $wpdb->prefix."Question";
     $quiz_result = $wpdb->get_results ("SELECT * FROM $table_name where question_number = '$question_number2' and question = '$question2'");
     echo $json = json_encode($quiz_result);