<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $quiz_img_path2 = utf8_decode($_GET['quiz_img_path1']); 
     $enter_question_number2 = utf8_decode($_GET['enter_question_number1']); 
     $select_quiz2 = utf8_decode($_GET['select_quiz1']);
     $enter_question2 = utf8_decode($_GET['enter_question1']);
     $enter_question_description2 = utf8_decode($_GET['enter_question_description1']);
     $Option12 = utf8_decode($_GET['Option11']);
     $Option22 = utf8_decode($_GET['Option21']);
     $Option32 = utf8_decode($_GET['Option31']);
     $Option42 = utf8_decode($_GET['Option41']);
     $Option52 = utf8_decode($_GET['Option51']);
     $Option62 = utf8_decode($_GET['Option61']);
     $Correct_Answer2 = utf8_decode($_GET['Correct_Answer1']);
     $table_name = $wpdb->prefix."Question";
   $result = $wpdb->get_results ("SELECT question FROM $table_name WHERE quiz_name='".$select_quiz2."' && question='".$enter_question2."' && question_number='".$enter_question_number2."'");

   if (count ($result) == "0") {
    if($enter_question2 != NULL && $Correct_Answer2 != NULL && $enter_question_number2 != NULL && $select_quiz2 != NULL && $Option12 != NULL && $Option22 != NULL){
        $sql = $wpdb->prepare( "insert into $table_name(question_number,quiz_name,question,question_description,option1,option2,option3,option4,option5,option6,correct_answer,question_image_name) values(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",$enter_question_number2,$select_quiz2,$enter_question2,$enter_question_description2,$Option12,$Option22,$Option32,$Option42,$Option52,$Option62,$Correct_Answer2,$quiz_img_path2);
       $wpdb->query($sql);
       echo "Question inseted.";
       }
 else {
        echo "Fill the required fields.";   
       }
   }
 else {
       echo "This data already exists.";
   }