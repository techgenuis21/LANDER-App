<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     //$result_quiz_name2 = utf8_decode($_GET['result_quiz_name1']); 
     $score2 = utf8_decode($_GET['score1']);
     $score_statement2 = utf8_decode($_GET['score_statement1']);
     $table_name = $wpdb->prefix."Result";
     $quiz_result = $wpdb->get_results ("SELECT * FROM $table_name where score = '$score2' and score_statement = '$score_statement2'");
     echo $json = json_encode($quiz_result);