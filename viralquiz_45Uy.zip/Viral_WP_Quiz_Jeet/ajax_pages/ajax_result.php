<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $enter_score2 = utf8_decode($_GET['enter_score1']); 
     $result_img_path2 = utf8_decode($_GET['result_img_path1']); 
    // $select_quiz_result2 = utf8_decode($_GET['select_quiz_result1']); 
     $Scores_Statement2 = utf8_decode($_GET['Scores_Statement1']); 
     $table_name = $wpdb->prefix."Result";
     $result = $wpdb->get_results ("SELECT score FROM $table_name WHERE score = '".$enter_score2."'");

     if (count ($result) == "0") {
       if($enter_score2 != NULL){
		$sql = $wpdb->prepare( "insert into $table_name(score,score_image_name,score_statement) values(%s,%s,%s)",$enter_score2,$result_img_path2, $Scores_Statement2 );
       $wpdb->query($sql);
       echo "Result Feedback Inserted";
       }
   }
   else {
       echo "This data already exists.";
   }  