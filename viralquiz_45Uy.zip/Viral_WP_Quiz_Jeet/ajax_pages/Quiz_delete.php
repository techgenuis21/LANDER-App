<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
  
      $deletee2 = utf8_decode($_GET['deletee1']); 
      
     $table_name = $wpdb->prefix."Quiz";
		$wpdb->delete( $table_name, array( 'quiz_title' => $deletee2 ), array( '%s' ) );
       //echo "$deletee2 has been Deleted";
       $table_name1 = $wpdb->prefix."Question";
		$wpdb->delete( $table_name1, array( 'quiz_name' => $deletee2 ), array( '%s' ) );
      // echo "$deletee2 has been Deleted";
       $table_name2 = $wpdb->prefix."Result";
		$wpdb->delete( $table_name2, array( 'result_quiz_name' => $deletee2 ), array( '%s' ) );
      // echo "$resudelet2 has been Deleted";