<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $hidden_question2 = utf8_decode($_GET['hidden_question1']);
     $hidden_question_no2 = utf8_decode($_GET['hidden_question_no1']);
     $enter_question_number2 = utf8_decode($_GET['enter_question_number1']); 
     $select_quiz2 = utf8_decode($_GET['select_quiz1']); 
     $enter_question2 = utf8_decode($_GET['enter_question1']);
     $enter_question_description2 = utf8_decode($_GET['enter_question_description1']);
     $Option12 = utf8_decode($_GET['Option11']);
     $Option22 = utf8_decode($_GET['Option21']);
     $Option32 = utf8_decode($_GET['Option31']);
     $Option42 = utf8_decode($_GET['Option41']);
     $Option52 = utf8_decode($_GET['Option51']);
     $Option62 = utf8_decode($_GET['Option61']);
     $Correct_Answer_opt2 = utf8_decode($_GET['Correct_Answer_opt1']);
     $questimgedit2 = utf8_decode($_GET['questimgedit1']); 
   
     $table_name1 = $wpdb->prefix."Question";
     $query = $wpdb->query("UPDATE {$table_name1} SET question_description = '{$enter_question_description2}', question_number = '{$enter_question_number2}', quiz_name = '{$select_quiz2}', question = '{$enter_question2}', option1 = '{$Option12}', option2 = '{$Option22}', option3 = '{$Option32}', option4 = '{$Option42}' , option5 = '{$Option52}', option6 = '{$Option62}', question_image_name = '{$questimgedit2}', correct_answer = '{$Correct_Answer_opt2}' WHERE question_number = '{$hidden_question_no2}' and question = '{$hidden_question2}'");
if ($query) {
echo "Question updation sucessfully done.";
}