<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
      $quesdelet2 = utf8_decode($_GET['quesdelet1']); 
      
     $table_name = $wpdb->prefix."Question";
		$wpdb->delete( $table_name, array( 'question' => $quesdelet2 ), array( '%s' ) );
       echo "This data has been deleted";