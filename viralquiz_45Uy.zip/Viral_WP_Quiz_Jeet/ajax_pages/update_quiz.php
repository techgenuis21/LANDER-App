<?php
$edit_file='';
if (!$edit_file)$edit_file = preg_replace('|wp-content.*$|','',__FILE__);
include($edit_file.'/wp-config.php');

     global $wpdb;
     $editlink2 = utf8_decode($_GET['editlink1']); 
     $editquiz2 = utf8_decode($_GET['editquiz1']); 
     $quizhidden2 = utf8_decode($_GET['quizhidden1']); 
   
     $table_name = $wpdb->prefix."Quiz";
     $query1 = $wpdb->query("UPDATE {$table_name} SET quiz_title = '{$editquiz2}', quiz_image_name = '{$editlink2}' WHERE quiz_title = '{$quizhidden2}'");
     $table_name1 = $wpdb->prefix."Question";
     $query2 = $wpdb->query("UPDATE {$table_name1} SET quiz_name = '{$editquiz2}' WHERE quiz_name = '{$quizhidden2}'");
     $table_name2 = $wpdb->prefix."Result";
     $query3 = $wpdb->query("UPDATE {$table_name2} SET result_quiz_name = '{$editquiz2}' WHERE result_quiz_name = '{$quizhidden2}'");

if($query1) 
{
echo "Quiz updation sucessfully done";
} if ($query2) {
echo ", Question updation sucessfully done";
} if ($query3){
echo ", Result updation sucessfully done";
}