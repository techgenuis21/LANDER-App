<?php
global $wpdb;
$table_name = $wpdb->prefix."Quiz";
$quiz_result = $wpdb->get_results ("SELECT quiz_title FROM $table_name");
?>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
 <link href="<?= plugins_url('css/bootstrap.min.css',__FILE__); ?>" rel="stylesheet" type="text/css"/>
 <script>
  function deletequiz(n,event){
         var del = confirm("Press ok and delete all the items related to this quiz.");
                   if (del == true){ 
                 var deletee =$(".quwstion_action_heading").find("#delete"+n).attr("title");//alert(deletee);
                deletee = encodeURIComponent(deletee);
                 $.ajax({
   		type: 'GET',
   		url: '<?php echo plugins_url( 'ajax_pages/Quiz_delete.php' , __FILE__ );?>',
   		data: "deletee1="+deletee,
                success: function(msg){
                  //alert(msg);
                  window.location.assign("<?= get_site_url()?>/wp-admin/admin.php?page=Add_New_Quiz");
                }
               });  
                }
               
                event.preventDefault();
              }
$(document).ready(function(){
for(var i=0;i<=<?= (count($quiz_result)); ?>;i++){
if(i % 2 != 0){
   $("."+i).css("background-color","#FFF");
}
       
   }
});
 </script>

 <div style="border:1px solid #ddd;width: 1063px;margin: 10px;">
 <div style="width: 1063px;display: flex;font-size: 15px;font-weight: 700;"> 
     <div style="width: 127px; border:1px solid #ddd;padding: 15px;" class="question_no_theading">Quiz Number</div>
      <div style="width: 684px; border:1px solid #ddd;padding: 15px;" class="question_theading">Quiz Name</div>
      <div style="width: 250px;border:1px solid #ddd;padding: 15px;" class="question_Action_theading">Action to be Taken</div>
   </div>    
 <div class="cnt" style="width: 100%;">
       <?php   for($i=0;$i<=count($quiz_result)-1;$i++){ $ch = $quiz_result[$i]->quiz_title; $num=$i+1;
   
 @$GLOBALS["activa$num"] = esc_attr( get_option("activa$num") );
?>
     <div class="scnt" style="width: 1063px;display: flex;font-size: 13px;font-weight: 600; ">      
      <div style="width: 127px; border:1px solid #ddd; padding: 7px;" class="quwstion_no_heading <?= $i+1; ?>"><input style="margin: 10px;" type="checkbox" name="activa<?= $i+1; ?>" id="activate" class="activate<?= $i+1; ?>" value="<?= $ch; ?>"<?php checked(@$GLOBALS["activa$num"], $ch );?>> <?= $i+1; ?> </div>
      <div style="width: 684px; padding: 16px; border:1px solid #ddd;" class="quwstion_heading <?= $i+1; ?>"><?= $quiz_result[$i]->quiz_title; ?></div>
      <div style="padding: 10px 0px 10px 0px; border:1px solid #ddd;" class="quwstion_action_heading <?= $i+1; ?>">
          <a href="<?= get_site_url()?>/wp-admin/admin.php?page=Add_New_Quiz" id="delete<?= $i; ?>" class="btn btn-danger btn-xs questiondelete" name="delete" onclick="deletequiz('<?= $i ?>')" title="<?= $quiz_result[$i]->quiz_title; ?>"><span class="glyphicon glyphicon-trash"></span> DELETE</a>
          <a id="delete<?= $i; ?>" class="btn btn-success btn-lg editbtn"  name="delete" onclick="editquiz('<?= $i ?>','<?= $quiz_result[$i]->quiz_title; ?>')" title="<?= $quiz_result[$i]->quiz_title; ?>"><span class="glyphicon glyphicon-edit"></span> EDIT</a>
      </div>
      </div>
    <?php $numb = $i;     
       }   
?>
    <input type="hidden" name="quesno" value="<?= $i; ?>">
 </div> </div>    
<input type="submit" id="Activate" name="Activate" value="Save" class="quz_btnmr button-primary">